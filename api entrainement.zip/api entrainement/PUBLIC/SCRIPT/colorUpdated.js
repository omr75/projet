// function updateColorCircle(id_vin, vin_couleur) {
//     console.log("Données reçues : ID du vin =", id_vin, ", Couleur =", vin_couleur);
//     // Trouver le cercle correspondant à l'ID du vin et mettre à jour sa couleur
//     const circle = document.querySelector(`.wine-circle[data-id_vin="${id_vin}"]`);
//     if (circle) {
//         circle.setAttribute('fill', vin_couleur);
//     } else {
//         console.log('Cercle trouvé :', circle);

//         console.error(`Cercle avec l'ID du vin ${id_vin} non trouvé.`);

//     }
// }
