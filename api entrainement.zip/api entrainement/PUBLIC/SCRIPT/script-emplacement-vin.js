function showModal(id_vin) {
            console.log('showModal appelé avec l\'ID :', id_vin);
        
            // Supprimer le modal précédent s'il existe
            closeModal();
        
            fetch(`http://localhost:3000/get/vin/${id_vin}`)
                .then(response => response.json())
                .then(data => {
                    console.log('Données reçues du serveur :', data);
                    console.log('Événement nouvelleCouleur déclenché avec les données :', data);
        
        
                    if (data.status === 1) {
                        showModal(data.vin); // Utilisez data.vin au lieu de data.vin
                    } else {
                        console.error('Erreur lors de la récupération des données de la BOUTEILLE');
                    }
                })
                .catch(error => console.error('Erreur :', error));
        }
    
        function closeModal() {
            console.log('closeModal appelé');
            const modal = document.querySelector('.modal');
            if (modal) {
                modal.remove();
            }
        }

    
        function showInfobulle(event) {
            // Récupérez l'ID du vin à partir de l'attribut data
            const id_vin = event.target.getAttribute('data-id_vin');
            // Obtenez l'infobulle
            const infobulle = document.getElementById('infobulle');
            // Mettez à jour le contenu de l'infobulle
            infobulle.textContent = `ID du vin: ${id_vin}`;
            // Positionnez l'infobulle à côté du cercle
            infobulle.style.left = `${event.pageX}px`;
            infobulle.style.top = `${event.pageY}px`;
            // Affichez l'infobulle
            infobulle.style.display = 'block';
        }
    
        // Fonction pour masquer l'infobulle
        function hideInfobulle() {
            // Obtenez l'infobulle
            const infobulle = document.getElementById('infobulle');
            // Cachez l'infobulle
            infobulle.style.display = 'none';
        }
    
        document.addEventListener('DOMContentLoaded', function () {
            const circles = document.querySelectorAll('.wine-circle');
    
            circles.forEach(circle => {
                circle.addEventListener('click', function (event) {
                    circle.addEventListener('mouseenter', showInfobulle);
                    circle.addEventListener('mouseleave', hideInfobulle); // Ajoutez cet événement
                    event.stopPropagation();  
                    const id_vin = this.dataset.id_vin;
                    console.log("ID de la bouteille:", id_vin);
                    showModal(id_vin);      
                });
            });
        });
       
        // function showModal(id_vin) {
        //     console.log('showModal appelé avec l\'ID :', id_vin);
    
        //     // Supprimer le modal précédent s'il existe
        //     closeModal();
    
        //     // Assurez-vous que la fonction showModal reçoit les données correctes
        // fetch(`http://localhost:3000/get/vin/${id_vin}`)
        //     .then(response => response.json()) // Assurez-vous que la réponse est traitée comme JSON
        //     .then(data => {
        //         console.log('Données reçues du serveur :', data);
        //         const id_vin = data.id_vin; // Assurez-vous que l'ID du vin est correctement extrait des données
        //         console.log('showModal appelé avec les données :', id_vin);
        //         showModal(id_vin); // Appelez showModal avec l'ID du vin
        //     })
        //     .catch(error => console.error('Erreur lors de la récupération des données du vin :', error));
        // }







// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// function updateColorCircle(id_vin, vin_couleur) {
//     // Trouver le cercle correspondant à l'ID du vin et mettre à jour sa couleur
//     const circle = document.querySelector(`.wine-circle[data-id_vin="${id_vin}"]`);
//     if (circle) {
//         circle.setAttribute('fill', vin_couleur);
//     } else {
//         console.error(`Cercle avec l'ID du vin ${id_vin} non trouvé.`);
//     }
// }

 
// document.addEventListener('DOMContentLoaded', function () {

// /* script-emplacement-vin.js */

// function showInfobulle(event) {
//     // Récupérez l'ID du vin à partir de l'attribut data
//     const id_vin = event.target.getAttribute('data-id_vin');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID du vin: ${id_vin}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }


// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

    
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle); // Ajoutez cet événement
//             event.stopPropagation();  
//             const id_vin = this.dataset.id_vin;
//             console.log("ID de la bouteille:", id_vin);
//             showModal(id_vin);      
//         });
//     });
    
   
// });
// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
            
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

    

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }





// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
            
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

    

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }






// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);
//             console.log('Événement nouvelleCouleur déclenché avec les données :', data);


//             if (data.status === 1) {
//                 showvinModal(data.vin); // Utilisez data.vin au lieu de data.vin
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }


// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//        <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }


// document.addEventListener('DOMContentLoaded', function () {

// /* script-emplacement-vin.js */

// function showInfobulle(event) {
//     // Récupérez l'ID du vin à partir de l'attribut data
//     const id_vin = event.target.getAttribute('data-id_vin');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID du vin: ${id_vin}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }


// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

    
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             console.log("ID de la bouteille:", id_vin);
//             showModal(id_vin);
           
         
//         });
//     });
   
// });

// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);
//             console.log('Événement nouvelleCouleur déclenché avec les données :', data);


//             if (data.status === 1) {
//                 showvinModal(data.vin); // Utilisez data.vin au lieu de data.vin
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }


// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//        <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }





// // Fonction pour mettre à jour la couleur du cercle sur la page d'emplacement
// function updateColor(color) {
//     const circle = document.getElementById('wine-circle').querySelector('circle');
//     if (circle) {
//         circle.setAttribute('fill', color);
//     }
// }

// // Écouter les événements de sélection de couleur émis depuis la page principale
// window.addEventListener('message', function(event) {
//     if (event.data && event.data.color) {
//         updateColor(event.data.color);
//     }
// });



//     var socket = io();
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//             // Appeler updateCircleColor avec l'ID sélectionné
//             updateCircleColor(id_vin, socket);
//         });
//     });

//     // Écouter l'événement 'nouvelleCouleur' pour mettre à jour la couleur du cercle
//     socket.on('updateColor', updateCircleColor);

//     // Fonction pour afficher l'infobulle
//     function showInfobulle(event) {
//         const bouteilleId = event.target.getAttribute('data-id_vin');
//         const infobulle = document.getElementById('infobulle');
//         infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//         infobulle.style.left = `${event.pageX}px`;
//         infobulle.style.top = `${event.pageY}px`;
//         infobulle.style.display = 'block';
//     }

//     // Fonction pour masquer l'infobulle
//     function hideInfobulle() {
//         const infobulle = document.getElementById('infobulle');
//         infobulle.style.display = 'none';
//     }

//     // Fonction pour mettre à jour la couleur du cercle
//     function updateCircleColor(id, socket) {
//         fetch(`/get/vin/${id}`)
//             .then(response => response.json())
//             .then(data => {
//                 if (data.status === 1) {
//                     const couleur = data.vin.vin_couleur;
//                     socket.emit('updateColor', { id: id, couleur: couleur });
//                 } else {
//                     console.error('Erreur lors de la récupération des détails du vin:', data.status_message);
//                 }
//             })
//             .catch(error => {
//                 console.error('Erreur lors de la récupération des détails du vin:', error);
//             });
//     }
// });

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }
// document.addEventListener('DOMContentLoaded', function () {
//     var socket = io();
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//             // Appeler updateCircleColor avec l'ID sélectionné
//             updateCircleColor(id_vin);
//         });
//     });
//     // Écouter l'événement 'nouvelleCouleur' pour mettre à jour la couleur du cercle
//     socket.on('updateColor', updateCircleColor);
// });

// function updateCircleColor(id) {
//     // Envoyer une requête AJAX pour récupérer les détails du vin, y compris la couleur
//     fetch(`/get/vin/${id}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.status === 1) {
//                 const couleur = data.vin.vin_couleur; // Supposons que 'vin_couleur' est le champ de couleur dans la réponse JSON
//                 // Émettre l'événement avec l'ID et la couleur à l'intérieur de cette promesse
//                 socket.emit('updateColor', { id: id, couleur: couleur });
//             } else {
//                 console.error('Erreur lors de la récupération des détails du vin:', data.status_message);
//             }
//         })
//         .catch(error => {
//             console.error('Erreur lors de la récupération des détails du vin:', error);
//         });
// }

// document.addEventListener('DOMContentLoaded', function () {
// //     const poignee = document.getElementById("poignee");
// //     const bouteille = document.getElementById("bouteille");
// //     const infosBouteille = document.getElementById("infos-bouteille");
// //     // Sélectionnez votre rectangle (remplacez "rectangle" par l'ID approprié)
// //     const rectangle = document.getElementById("rectangle");

// // // Ajoutez un gestionnaire d'événements pour le clic sur le rectangle
// //     rectangle.addEventListener("click", function() {
// //         // Ajoutez ici votre logique d'animation
// //         alert("Animation sur le rectangle !");
 


// //     // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
// //     poignee.addEventListener("click", function() {
// //         // Animation pour ouvrir la cave (exemple)
// //         alert("La cave s'ouvre !");
// //     });

// //     // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
// //     bouteille.addEventListener("click", function() {
// //         // Animation pour déplacer la bouteille (exemple)
// //         bouteille.setAttribute("cx", "50"); // Nouvelle position en x
// //         bouteille.setAttribute("cy", "100"); // Nouvelle position en y

// //         // Afficher les informations sur la bouteille
// //         infosBouteille.style.display = "block";
// //         infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
// //     });

//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
//     // Écouter l'événement 'nouvelleCouleur' pour mettre à jour la couleur du cercle
//     socket.on('nouvelleCouleur', updateCircleColor);
// });

// function updateCircleColor() {
//     const id = document.getElementById('id_vin').value; // Récupérer l'ID du vin
//     const couleur = document.getElementById('vin_couleur').value; // Récupérer la couleur sélectionnée

//     socket.emit('updateColor', { id: id, couleur: couleur }); // Émettre l'événement avec l'ID et la couleur
// }













// // Fonction pour afficher une infobulle avec l'ID de la bouteille
// function showInfobulle(event) {
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     const infobulle = document.getElementById('infobulle');
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     const infobulle = document.getElementById('infobulle');
//     infobulle.style.display = 'none';
// }

// // Fonction pour fermer le modal
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// // Fonction pour afficher le modal avec les informations sur la bouteille
// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// // // Fonction pour afficher le modal avec les informations sur la bouteille
// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);
// }
//     // Ajouter un gestionnaire d'événement pour le bouton de fermeture
//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// // Fonction pour mettre à jour la couleur du cercle en fonction de l'ID de la bouteille
// function updateCircleColor(data) {
//     const circle = document.querySelector(`[data-id_vin="${data.id}"]`);
//     if (circle) {
//         circle.setAttribute('fill', data.couleur);
//     }
// }

// // Écouter l'événement DOMContentLoaded pour initialiser la page
// document.addEventListener('DOMContentLoaded', function () {
//     // Sélectionner tous les cercles avec la classe .wine-circle
//     const circles = document.querySelectorAll('.wine-circle');

//     // Ajouter des gestionnaires d'événements pour chaque cercle
//     circles.forEach(circle => {
//         // Ajouter les gestionnaires d'événements mouseenter et mouseleave une seule fois
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//         // Ajouter un gestionnaire d'événement pour le clic sur le cercle
//         circle.addEventListener('click', function (event) {
//             event.stopPropagation();
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
//     // Écouter l'événement 'nouvelleCouleur' pour mettre à jour la couleur du cercle
//     socket.on('nouvelleCouleur', updateCircleColor);
// });


// function showInfobulle(event) {
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     const infobulle = document.getElementById('infobulle');
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     const infobulle = document.getElementById('infobulle');
//     infobulle.style.display = 'none';
// }



// // Fonction pour fermer le modal
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     // Autres initialisations de votre page

//     // Sélectionner tous les éléments avec la classe .wine-circle
//     const circles = document.querySelectorAll('.wine-circle');

//     // Ajouter des gestionnaires d'événements pour chaque cercle
//     circles.forEach(circle => {
//         // Ajouter les gestionnaires d'événements mouseenter et mouseleave une seule fois
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//         circle.addEventListener('click', function (event) {
//             event.stopPropagation();
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });

// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data);
            
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// document.addEventListener("DOMContentLoaded", function() {
//     // Sélectionnez tous les cercles avec la classe "wine-circle"
//     var circles = document.querySelectorAll('.wine-circle');

//     // Parcourez chaque cercle
//     circles.forEach(function(circle) {
//         // Obtenez l'ID de la bouteille associée à ce cercle
//         var vinId = circle.getAttribute('data-id_vin');

//         // Mettez à jour la couleur du cercle en fonction de l'ID de la bouteille
//         socket.on('nouvelleCouleur', function(data) {
//             if (data.id === vinId) {
//                 circle.setAttribute('fill', data.couleur);
//             }
//         });
//     });
// });

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

    

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function updateCircleColor() {
//     var selectedColor = document.getElementById("vin_couleur").value;
//     var vinId = document.getElementById("id_vin").value;

//     // Mettez à jour la couleur du cercle approprié en fonction de l'ID du vin
//     if (vinId === "1") {
//         document.getElementById("circle1").setAttribute("fill", selectedColor);
//     } else if (vinId === "2") {
//         document.getElementById("circle2").setAttribute("fill", selectedColor);
//     }
//     // Ajoutez d'autres conditions pour les autres cercles si nécessaire
// }


// /* script-emplacement.js */

// function showInfobulle(event) {
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     const infobulle = document.getElementById('infobulle');
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     const infobulle = document.getElementById('infobulle');
//     infobulle.style.display = 'none';
// }




// // Fonction pour fermer le modal
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     // Autres initialisations de votre page

//     // Sélectionner tous les éléments avec la classe .wine-circle
//     const circles = document.querySelectorAll('.wine-circle');

//     // Ajouter des gestionnaires d'événements pour chaque cercle
//     circles.forEach(circle => {
//         // Ajouter les gestionnaires d'événements mouseenter et mouseleave une seule fois
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//         circle.addEventListener('click', function (event) {
//             event.stopPropagation();
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });











// /* script-emplacement.js */

// function showInfobulle(event) {
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     const infobulle = document.getElementById('infobulle');
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     const infobulle = document.getElementById('infobulle');
//     infobulle.style.display = 'none';
// }

// // Fonction pour mettre à jour la couleur des cercles en fonction de la sélection
// function updateCircleColor() {
//     // Récupérer la valeur sélectionnée dans le menu déroulant
//     var selectedColor = document.getElementById("vin_couleur").value;

//     // Récupérer tous les cercles SVG
//     var circles = document.querySelectorAll(".wine-circle");

//     // Parcourir tous les cercles et mettre à jour leur couleur
//     circles.forEach(function(circle) {
//         // Obtenez la liste de couleurs associée à chaque cercle
//         var colors = JSON.parse(circle.getAttribute("data-couleur"));

//         // Si la couleur sélectionnée est dans la liste des couleurs du cercle, mettez à jour la couleur du cercle
//         if (colors.includes(selectedColor)) {
//             circle.style.fill = selectedColor;
//         } else {
//             // Sinon, mettez une couleur par défaut
//             circle.style.fill = 'gray'; // Ou une autre couleur par défaut de votre choix
//         }
//     });
// }

// // Fonction pour fermer le modal
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     // Autres initialisations de votre page

//     // Sélectionner tous les éléments avec la classe .wine-circle
//     const circles = document.querySelectorAll('.wine-circle');

//     // Ajouter des gestionnaires d'événements pour chaque cercle
//     circles.forEach(circle => {
//         // Ajouter les gestionnaires d'événements mouseenter et mouseleave une seule fois
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//         circle.addEventListener('click', function (event) {
//             event.stopPropagation();
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });

// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//                 updateCircleColor(); // Mettre à jour la couleur des cercles après l'ajout du modal
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Récupérer la couleur du vin
//     const vinCouleur = vinData.vin_couleur;

//     // Appliquer la couleur au cercle
//     const cercle = document.querySelector(`.wine-circle[data-id_vin="${vinData.id_vin}"]`);
//     if (cercle) {
//         cercle.style.fill = vinCouleur;
//     } else {
//         console.error('Cercle non trouvé pour ce vin');
//     }

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// // Mettre à jour la couleur des cercles au chargement de la page
// updateCircleColor();













// /* script-emplacement.js */

// function showInfobulle(event) {
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     const infobulle = document.getElementById('infobulle');
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     const infobulle = document.getElementById('infobulle');
//     infobulle.style.display = 'none';
// }
// document.addEventListener('DOMContentLoaded', function () {
//     // Autres initialisations de votre page

//     // Sélectionner tous les éléments avec la classe .wine-circle
//     const circles = document.querySelectorAll('.wine-circle');

//     // Ajouter des gestionnaires d'événements pour chaque cercle
//     circles.forEach(circle => {
//         // Ajouter les gestionnaires d'événements mouseenter et mouseleave une seule fois
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//         circle.addEventListener('click', function (event) {
//             event.stopPropagation();
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });




// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// function updateCircleColor() {
//     // Récupérer la valeur sélectionnée dans le menu déroulant
//     var selectedColor = document.getElementById("vin_couleur").value;

//     // Récupérer tous les cercles SVG
//     var circles = document.querySelectorAll(".wine-circle");

//     // Parcourir tous les cercles et mettre à jour leur couleur
//     circles.forEach(function(circle) {
//         // Obtenez la liste de couleurs associée à chaque cercle
//         var colors = JSON.parse(circle.getAttribute("data-couleur"));

//         // Si la couleur sélectionnée est dans la liste des couleurs du cercle, mettez à jour la couleur du cercle
//         if (colors.includes(selectedColor)) {
//             circle.style.fill = selectedColor;
//         } else {
//             // Sinon, mettez une couleur par défaut
//             circle.style.fill = 'gray'; // Ou une autre couleur par défaut de votre choix
//         }
//     });
// }


// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));

// }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal); 

//     // Récupérer la couleur du vin
//     const vinCouleur = vinData.vin_couleur;

//     // Appliquer la couleur au cercle
//     const cercle = document.querySelector(`.wine-circle[data-id_vin="${vinData.id_vin}"]`);
//     if (cercle) {
//         cercle.style.fill = vinCouleur;
//     } else {
//         console.error('Cercle non trouvé pour ce vin');
//     }


//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }
// updateCircleColor();


// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//     const bouteille = document.getElementById("bouteille");
//     const infosBouteille = document.getElementById("infos-bouteille");
//     // Sélectionnez votre rectangle (remplacez "rectangle" par l'ID approprié)
//     const rectangle = document.getElementById("rectangle");

//     // Ajoutez un gestionnaire d'événements pour le clic sur le rectangle
//     rectangle.addEventListener("click", function() {
//         // Ajoutez ici votre logique d'animation
//         alert("Animation sur le rectangle !");
//     });


//     // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//     poignee.addEventListener("click", function() {
//         // Animation pour ouvrir la cave (exemple)
//         alert("La cave s'ouvre !");
//     });

//     // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//     bouteille.addEventListener("click", function() {
//         // Animation pour déplacer la bouteille (exemple)
//         bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//         bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//         // Afficher les informations sur la bouteille
//         infosBouteille.style.display = "block";
//         infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//     });

//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal); 

//     // Récupérer la couleur du vin
//     const vinCouleur = vinData.vin_couleur;

//     // Appliquer la couleur au cercle
//     const cercle = document.querySelector(`.wine-circle[data-id_vin="${vinData.id_vin}"]`);
//     if (cercle) {
//         cercle.style.fill = vinCouleur;
//     } else {
//         console.error('Cercle non trouvé pour ce vin');
//     }

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur le VIN</h2>
//             <p>id_vin : ${vinData.id_vin}</p>
//             <p>Vin couleur : ${vinData.vin_couleur}</p>
//             <p>vin_region : ${vinData.vin_region}</p>
//             <p>vin_appellation : ${vinData.vin_appellation}</p>
//             <p>vin_terroir : ${vinData.vin_terroir}</p>
//             <p>vin_domaine : ${vinData.vin_domaine}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal); 
//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }






// document.addEventListener('DOMContentLoaded', function() {
//     const cercle = document.getElementById('cercle');
    
//     // Ajoutez un écouteur d'événements au clic sur le cercle
//     cercle.addEventListener('click', function() {
//         // Obtenez l'ID de la bouteille associée au cercle
//         const id_vin = cercle.getAttribute('data-id_vin');

//         // Vérifiez si l'ID de la bouteille est valide avant d'afficher le modal
//         if (id_vin !== undefined && id_vin !== null) {
//             showModal(id_vin);
//         } else {
//             console.error('Erreur: ID de bouteille non disponible');
//         }
//     });
// });

// // Fonction pour afficher le modal avec les données de la bouteille
// function showModal(id_vin) {
//     // Fermez tout modal ouvert précédemment
//     closeModal();

//     // Effectuez une requête Fetch pour récupérer les données de la bouteille
//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_vin !== undefined) {
//                 // Affichez les données de la bouteille dans le modal
//                 showModalData(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showModalData(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `
//         <p>ID : ${data.id_vin}</p>
//         <p>Durée : ${data.vin_duree}</p>
//         <p>Millésime : ${data.vin_millesime}</p>
//         <p>Cote : ${data.vin_cote}</p>
//         <p>Prix : ${data.vin_prix}</p>
//         <p>Date de consommation : ${data.vin_date_conso}</p>
//         <p>Remarques : ${data.vin_remarques}</p>
//         <p>ID Vin : ${data.id_vin}</p>
//         <p>Place : ${data.place}</p>
//         <p>Presence : ${data.presence}</p>`;

//     // Afficher le modal après avoir inséré les données
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// // Fonction pour fermer le modal
// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
// }








// // Assurez-vous que le DOM est chargé avant d'attacher des écouteurs d'événements
// document.addEventListener('DOMContentLoaded', function() {
//     const cercle = document.getElementById('cercle');
    
//     // Ajoutez un écouteur d'événements au clic sur le cercle
//     cercle.addEventListener('click', function() {
//         // Obtenez l'ID de la bouteille associée au cercle
//         const id_vin = cercle.getAttribute('data-id-vin');

//         // Vérifiez si l'ID de la bouteille est valide avant d'afficher le modal
//         if (id_vin !== undefined && id_vin !== null) {
//             showModal(id_vin);
//         } else {
//             console.error('Erreur: ID de bouteille non disponible');
//         }
//     });
// });

// // Fonction pour afficher le modal
// function showModal(id_vin) {
//     // Supprimez le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_vin !== undefined) {
//                 showvinModal(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showvinModal(vinData) {
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${vinData.id_vin}</p>
//             <p>Durée : ${vinData.vin_duree}</p>
//             <p>Millésime : ${vinData.vin_millesime}</p>
//             <p>Cote : ${vinData.vin_cote}</p>
//             <p>Prix : ${vinData.vin_prix}</p>
//             <p>Date de consommation : ${vinData.vin_date_conso}</p>
//             <p>Remarques : ${vinData.vin_remarques}</p>
//             <p>ID Vin : ${vinData.id_vin}</p>
//             <p>Place : ${vinData.place}</p>
//             <p>Presence : ${vinData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Ajoutez un événement pour fermer le modal en cliquant sur le bouton de fermeture
//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM:', modal);
// }


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;
    
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block'; // Afficher le modal
//     }
    
//     function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
//     }
    





// // Fonction pour afficher le modal
// function showModal(id_vin) {
//     // Supprimez le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_vin !== undefined) {
//                 showvinModal(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showvinModal(vinData) {
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${vinData.id_vin}</p>
//             <p>Durée : ${vinData.vin_duree}</p>
//             <p>Millésime : ${vinData.vin_millesime}</p>
//             <p>Cote : ${vinData.vin_cote}</p>
//             <p>Prix : ${vinData.vin_prix}</p>
//             <p>Date de consommation : ${vinData.vin_date_conso}</p>
//             <p>Remarques : ${vinData.vin_remarques}</p>
//             <p>ID Vin : ${vinData.id_vin}</p>
//             <p>Place : ${vinData.place}</p>
//             <p>Presence : ${vinData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Ajoutez un événement pour fermer le modal en cliquant sur le bouton de fermeture
//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM:', modal);
// }

// // Fonction pour supprimer le modal
// function closeModal() {
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }






















// /* script-emplacement.js */

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);
//             if (data.length > 0) { // Assurez-vous que vous recevez au moins une bouteille
//                 showvinModal(data);
//             } else {
//                 console.error('Aucune donnée de la bouteille trouvée pour cet ID');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// // function showModal(id_vin) {
// //     console.log('showModal appelé avec l\'ID :', id_vin);

// //     // Supprimer le modal précédent s'il existe
// //     closeModal();

// //     fetch(`http://localhost:3000/get/vin`)
// //         .then(response => response.json())
// //         .then(data => {
// //             // console.log('Données reçues du serveur :', data);
// //             console.log('Données reçues du serveur :', data);


// //             if (data.status === 1) {
// //                 showvinModal(data.vin);
// //             } else {
// //                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
// //             }
// //         })
// //         .catch(error => console.error('Erreur :', error));
// // }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);
    

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${vinData.id_vin}</p>
//             <p>Durée : ${vinData.vin_duree}</p>
//             <p>Millésime : ${vinData.vin_millesime}</p>
//             <p>Cote : ${vinData.vin_cote}</p>
//             <p>Prix : ${vinData.vin_prix}</p>
//             <p>Date de consommation : ${vinData.vin_date_conso}</p>
//             <p>Remarques : ${vinData.vin_remarques}</p>
//             <p>ID Vin : ${vinData.id_vin}</p>
//             <p>Place : ${vinData.place}</p>
//             <p>Presence : ${vinData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// // Définir les valeurs à mettre à jour
// const id_vin = 100; // Remplacez cette valeur par l'ID de la bouteille que vous souhaitez mettre à jour
// const vin_duree = 10;
// const vin_millesime = 2014;
// const vin_cote = 17;
// const vin_prix = 100;
// const vin_date_conso = NULL;
// const vin_remarques = "Remise 20%";
// const id_vin = 16;

// // Effectuer la requête PUT
// fetch(`http://localhost:3000/update/vin/${id_vin}`, {
//     method: 'PUT',
//     headers: {
//         'Content-Type': 'application/json'
//     },
//     body: JSON.stringify({
//         id_vin: id_vin,
//         vin_duree: vin_duree,
//         vin_millesime: vin_millesime,
//         vin_cote: vin_cote,
//         vin_prix: vin_prix,
//         vin_date_conso: vin_date_conso,
//         vin_remarques: vin_remarques,
//         id_vin: id_vin
//     })
// }).then(response => {
//     if (!response.ok) {
//         throw new Error('La requête PUT a échoué');
//     }
//     return response.json();
// }).then(data => {
//     console.log('Réponse du serveur:', data);
// }).catch(error => {
//     console.error('Erreur lors de la requête PUT:', error);
// });


// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//     const bouteille = document.getElementById("bouteille");
//     const infosBouteille = document.getElementById("infos-bouteille");
//     // Sélectionnez votre rectangle (remplacez "rectangle" par l'ID approprié)
//     const rectangle = document.getElementById("rectangle");

// // Ajoutez un gestionnaire d'événements pour le clic sur le rectangle
//     rectangle.addEventListener("click", function() {
//         // Ajoutez ici votre logique d'animation
//         alert("Animation sur le rectangle !");
//     });


//     // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//     poignee.addEventListener("click", function() {
//         // Animation pour ouvrir la cave (exemple)
//         alert("La cave s'ouvre !");
//     });

//     // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//     bouteille.addEventListener("click", function() {
//         // Animation pour déplacer la bouteille (exemple)
//         bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//         bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//         // Afficher les informations sur la bouteille
//         infosBouteille.style.display = "block";
//         infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//     });

//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });



// const socket = io('http://localhost:3000');

// socket.on('data', (data) => {
//     console.log();
//     // Sélectionner le corps du tableau
//     const tableBody = document.querySelector('#mesures-table tbody');

//     // Créer une nouvelle ligne pour les nouvelles données
//     const newRow = document.createElement('tr');

//     // Remplir la nouvelle ligne avec les données reçues
//     newRow.innerHTML = `
//         <td>${data.Humidite}</td>
//         <td>${data.Temperature}</td>
//         <td>${data.Time}</td>
//     `;
    


//     // Ajouter la nouvelle ligne au corps du tableau
//     tableBody.appendChild(newRow);
// });










// /* script-emplacement.js */

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_vin');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }


// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//   const bouteille = document.getElementById("bouteille");
//   const infosBouteille = document.getElementById("infos-bouteille");

//   // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//   poignee.addEventListener("click", function() {
//     // Animation pour ouvrir la cave (exemple)
//     alert("La cave s'ouvre !");
//   });

//   // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//   bouteille.addEventListener("click", function() {
//     // Animation pour déplacer la bouteille (exemple)
//     bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//     bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//     // Afficher les informations sur la bouteille
//     infosBouteille.style.display = "block";
//     infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//   });

//     const circles = document.querySelectorAll('.wine-circle');
//     // const infobulle = document.getElementById('infobulle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });


// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${vinData.id_vin}</p>
//             <p>Durée : ${vinData.vin_duree}</p>
//             <p>Millésime : ${vinData.vin_millesime}</p>
//             <p>Cote : ${vinData.vin_cote}</p>
//             <p>Prix : ${vinData.vin_prix}</p>
//             <p>Date de consommation : ${vinData.vin_date_conso}</p>
//             <p>Remarques : ${vinData.vin_remarques}</p>
//             <p>ID Vin : ${vinData.id_vin}</p>
//             <p>PLACE : ${vinData.Place}</p>
//             <p>Precense : ${vinData.Presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     // const modalContent = document.querySelector('.modal-content');
//     // modalContent.style.position = 'fixed';
//     // modalContent.style.top = '50%';
//     // modalContent.style.left = '50%';
//     // modalContent.style.transform = 'translate(-50%, -50%)';
//     // modalContent.style.backgroundColor = 'white';
//     // modalContent.style.padding = '20px';
//     // modalContent.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }
// // // script-emplacement.js
// // // ...
// // const circleGeometry = new THREE.CircleGeometry(20, 32);
// // const circleMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });

// // function create3DCircle(x, y, z) {
// //     const circleMesh = new THREE.Mesh(circleGeometry, circleMaterial);
// //     circleMesh.position.set(x, y, z);
// //     scene.add(circleMesh);
// // }

// // // Utilisez la fonction create3DCircle pour chaque cercle existant
// // create3DCircle(50, 100, 0);
// // create3DCircle(100, 100, 0);
// // // ...







// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }















// /* script-emplacement.js */

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function () {
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });

// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }


// function showvinModal(vinData) {
//     console.log('showvinModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     // Ajoutez des logs pour déboguer les propriétés de vinData
//     console.log('ID :', vinData.id_vin);
//     console.log('Durée :', vinData.vin_duree);
//     console.log('Millésime :', vinData.vin_millesime);
//     // ... Ajoutez des logs pour chaque propriété

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${vinData.id_vin}</p>
//         <p>Durée : ${vinData.vin_duree}</p>
//         <p>Millésime : ${vinData.vin_millesime}</p>
//         <p>Cote : ${vinData.vin_cote}</p>
//         <p>Prix : ${vinData.vin_prix}</p>
//         <p>Date de consommation : ${vinData.vin_date_conso}</p>
//         <p>Remarques : ${vinData.vin_remarques}</p>
//         <p>ID Vin : ${vinData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// function showvinModal(vinData) {
//     console.log('showModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     console.log('showModal appelé');
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${vinData.id_vin}</p>
//         <p>Durée : ${vinData.vin_duree}</p>
//         <p>Millésime : ${vinData.vin_millesime}</p>
//         <p>Cote : ${vinData.vin_cote}</p>
//         <p>Prix : ${vinData.vin_prix}</p>
//         <p>Date de consommation : ${vinData.vin_date_conso}</p>
//         <p>Remarques : ${vinData.vin_remarques}</p>
//         <p>ID Vin : ${vinData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

































// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showvinModal(vinData) {
//     console.log('showModal appelé avec les données :', vinData);

//     if (!vinData || vinData.id_vin === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     console.log('showModal appelé');
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${vinData.id_vin}</p>
//         <p>Durée : ${vinData.vin_duree}</p>
//         <p>Millésime : ${vinData.vin_millesime}</p>
//         <p>Cote : ${vinData.vin_cote}</p>
//         <p>Prix : ${vinData.vin_prix}</p>
//         <p>Date de consommation : ${vinData.vin_date_conso}</p>
//         <p>Remarques : ${vinData.vin_remarques}</p>
//         <p>ID Vin : ${vinData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function () {
//             const id_vin = this.dataset.id_vin;
//             showModal(id_vin);
//         });
//     });
// });


// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer la modal existante
//     closeModal();

//     fetch(`http://localhost:3000/get/vin/${id_vin}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data && data.status === 1 && data.vin) {
//                 showvinModal(data.vin);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// // ...

// const closeButton = modal.querySelector('#closeButton');
// closeButton.addEventListener('click', closeModal);
