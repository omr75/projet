// document.addEventListener('DOMContentLoaded', function () {
//     const champ = document.querySelector('.champ');

//     let windStrength = 0; // Force du vent

//     // Fonction pour ajuster la force du vent
//     function adjustWindStrength() {
//         windStrength = Math.random() * 20 - 10; // Valeur aléatoire entre -10 et 10
//     }

//     // Fonction pour animer les herbes en réponse au vent
//     function swayGrass() {
//         const swayAngle = windStrength * 2; // Angle de balancement proportionnel à la force du vent
//         champ.style.animation = `sway 1s infinite alternate ease-in-out`;
//         champ.style.transform = `rotate(${swayAngle}deg)`;
//     }

//     // Appel initial de la fonction d'animation
//     swayGrass();

//     // Appel périodique pour ajuster la force du vent et relancer l'animation
//     setInterval(function() {
//         adjustWindStrength();
//         swayGrass();
//     }, 5000); // Ajustez la fréquence selon vos besoins
// });
