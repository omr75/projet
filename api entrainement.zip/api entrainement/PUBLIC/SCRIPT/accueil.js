document.addEventListener('DOMContentLoaded', () => {
    // Récupérer la liste des dernières bouteilles ajoutées
    fetch('http://localhost:3000/get/bouteilles')
        .then(response => response.json())
        .then(data => {
            const wineInfoList = document.getElementById('wine-info-list');
            // Effacer le contenu précédent
            wineInfoList.innerHTML = '';

            // Ajouter chaque bouteille à la liste
            data.forEach(bouteille => {
                const listItem = document.createElement('li');
                listItem.textContent = `Bouteille ajoutée : ${bouteille.bouteilles_remarques}`;
                wineInfoList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Erreur lors de la récupération des données :', error));

    // Récupérer et afficher les dernières bouteilles ajoutées
    fetch('/get/latest_bouteilles')
        .then(response => response.json())
        .then(data => {
            const latestAddedBouteillesList = document.getElementById('latestAddedBouteilles');
            // Effacer le contenu précédent pour éviter les doublons
            latestAddedBouteillesList.innerHTML = '';
            data.forEach(bouteille => {
                const listItem = document.createElement('li');
                listItem.textContent = `ID: ${bouteille.id_bouteilles}, Duree: ${bouteille.bouteilles_duree}, Millesime: ${bouteille.bouteilles_millesime}, Cote: ${bouteille.bouteilles_cote}, Prix: ${bouteille.bouteilles_prix}, Date Conso: ${bouteille.bouteilles_date_conso}, Remarques: ${bouteille.bouteilles_remarques}, ID Vin: ${bouteille.id_vin}`;
                latestAddedBouteillesList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Erreur lors de la récupération des dernières bouteilles ajoutées :', error));

    // Récupérer et afficher les dernières bouteilles supprimées
    fetch('/get/latest_deleted_bouteilles')
        .then(response => response.json())
        .then(data => {
            const latestDeletedBouteillesList = document.getElementById('latestDeletedBouteilles');
            // Effacer le contenu précédent pour éviter les doublons
            latestDeletedBouteillesList.innerHTML = '';
            data.forEach(bouteille => {
                const listItem = document.createElement('li');
                listItem.textContent = `ID: ${bouteille.id_bouteilles}, Duree: ${bouteille.bouteilles_duree}, Millesime: ${bouteille.bouteilles_millesime}, Cote: ${bouteille.bouteilles_cote}, Prix: ${bouteille.bouteilles_prix}, Date Conso: ${bouteille.bouteilles_date_conso}, Remarques: ${bouteille.bouteilles_remarques}, ID Vin: ${bouteille.id_vin}`;
                latestDeletedBouteillesList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Erreur lors de la récupération des dernières bouteilles supprimées :', error));


});
