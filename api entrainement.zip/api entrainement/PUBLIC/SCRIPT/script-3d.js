// const scene = new THREE.Scene();
// const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
// const renderer = new THREE.WebGLRenderer();

// renderer.setSize(window.innerWidth, window.innerHeight);
// document.getElementById('scene-container').appendChild(renderer.domElement);

// // Ajustez la position de la caméra
// camera.position.z = 50;

// // Animation de rendu
// const animate = function () {
//     requestAnimationFrame(animate);

//     // Ajoutez des animations ou interactions ici

//     renderer.render(scene, camera);
// };

// animate();