





function closeModal() {
    console.log('closeModal appelé');
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}
// Supposons que "couleurs" soit un tableau contenant les couleurs des vins récupérées depuis la base de données
const couleurs = ['BLANC', 'BLANC MOELLEUX', 'CHAMPAGNE', 'ROSE', 'ROUGE', 'ROUGE MOELLEUX'];

// Sélectionnez tous les cercles SVG avec la classe "wine-circle"
const cercles = document.querySelectorAll('.wine-circle');

// Parcourez chaque cercle et associez-lui une couleur
cercles.forEach((cercle, index) => {
    cercle.setAttribute('fill', couleurs[index]);
});







function showModal(id_bouteilles, id_vin) {
    console.log('showModal appelé avec l\'ID :', id_bouteilles);

    // Supprimer le modal précédent s'il existe
    closeModal();

    // Effectuer une requête pour récupérer les données de la bouteille et les informations sur le vin associées
    Promise.all([
        fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`).then(response => response.json())
    ])
    .then(([bouteillesData]) => {
        // Récupérer id_vin à partir des données de la bouteille
        const id_vin = bouteillesData.bouteilles.id_vin;
    
        // Maintenant que vous avez id_vin, vous pouvez récupérer les données du vin
        fetch(`http://localhost:3000/get/vin/${id_vin}`).then(response => response.json())
        .then(vinsData => {
            console.log('Données reçues du serveur :', bouteillesData, vinsData);
    
            if (bouteillesData.status === 1 && vinsData.status === 1) {
                showBouteillesModal(bouteillesData.bouteilles, vinsData.vin);
            } else {
                console.error('Erreur lors de la récupération des données de la BOUTEILLE ou du VIN');
            }
        })
        .catch(error => console.error('Erreur :', error));
    })
    .catch(error => console.error('Erreur :', error));
    
}


function showBouteillesModal(bouteillesData, vinData) {
    console.log('showBouteillesModal appelé avec les données de la bouteille et du vin :', bouteillesData, vinData);

    if (!bouteillesData || !vinData || bouteillesData.id_bouteilles === undefined || vinData.id_vin === undefined) {
        console.error('Données de bouteille ou de vin incorrectes');
        return;
    }

    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
        <div class="modal-content">
            <h2>Informations sur la BOUTEILLE et le VIN</h2>
            <p>ID Bouteille : ${bouteillesData.id_bouteilles}</p>
            <p>Durée : ${bouteillesData.bouteilles_duree}</p>
            <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
            <p>Cote : ${bouteillesData.bouteilles_cote}</p>
            <p>Prix : ${bouteillesData.bouteilles_prix}</p>
            <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
            <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
            <p>ID Vin : ${bouteillesData.id_vin}</p>
            <hr>
            <p>Couleur : ${vinData.vin_couleur}</p>
            <p>Région : ${vinData.vin_region}</p>
            <p>Appellation : ${vinData.vin_appellation}</p>
            <p>Terroir : ${vinData.vin_terroir}</p>
            <p>Domaine : ${vinData.vin_domaine}</p>
            <button id="closeButton">Fermer</button>
        </div>
    `;
    document.body.appendChild(modal);

    // Afficher la modal
    modal.style.display = 'block';

    const closeButton = modal.querySelector('#closeButton');
    closeButton.addEventListener('click', closeModal);

    console.log('Modal ajoutée au DOM :', modal);
}









// /* script-emplacement.js */

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_bouteilles');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//     const bouteille = document.getElementById("bouteille");
//     const infosBouteille = document.getElementById("infos-bouteille");
//     // Sélectionnez votre rectangle (remplacez "rectangle" par l'ID approprié)
//     const rectangle = document.getElementById("rectangle");

// // Ajoutez un gestionnaire d'événements pour le clic sur le rectangle
//     rectangle.addEventListener("click", function() {
//         // Ajoutez ici votre logique d'animation
//         alert("Animation sur le rectangle !");
//     });


//     // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//     poignee.addEventListener("click", function() {
//         // Animation pour ouvrir la cave (exemple)
//         alert("La cave s'ouvre !");
//     });

//     // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//     bouteille.addEventListener("click", function() {
//         // Animation pour déplacer la bouteille (exemple)
//         bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//         bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//         // Afficher les informations sur la bouteille
//         infosBouteille.style.display = "block";
//         infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//     });

//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_bouteilles = this.dataset.id_bouteilles;
//             showModal(id_bouteilles);
//         });
//     });
// });

// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showBouteillesModal(bouteillesData) {
//     console.log('showBouteillesModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${bouteillesData.id_bouteilles}</p>
//             <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//             <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//             <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//             <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//             <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//             <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//             <p>ID Vin : ${bouteillesData.id_vin}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }














// document.addEventListener('DOMContentLoaded', function() {
//     const cercle = document.getElementById('cercle');
    
//     // Ajoutez un écouteur d'événements au clic sur le cercle
//     cercle.addEventListener('click', function() {
//         // Obtenez l'ID de la bouteille associée au cercle
//         const id_bouteilles = cercle.getAttribute('data-id_bouteilles');

//         // Vérifiez si l'ID de la bouteille est valide avant d'afficher le modal
//         if (id_bouteilles !== undefined && id_bouteilles !== null) {
//             showModal(id_bouteilles);
//         } else {
//             console.error('Erreur: ID de bouteille non disponible');
//         }
//     });
// });

// // Fonction pour afficher le modal avec les données de la bouteille
// function showModal(id_bouteilles) {
//     // Fermez tout modal ouvert précédemment
//     closeModal();

//     // Effectuez une requête Fetch pour récupérer les données de la bouteille
//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_bouteilles !== undefined) {
//                 // Affichez les données de la bouteille dans le modal
//                 showModalData(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showModalData(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `
//         <p>ID : ${data.id_bouteilles}</p>
//         <p>Durée : ${data.bouteilles_duree}</p>
//         <p>Millésime : ${data.bouteilles_millesime}</p>
//         <p>Cote : ${data.bouteilles_cote}</p>
//         <p>Prix : ${data.bouteilles_prix}</p>
//         <p>Date de consommation : ${data.bouteilles_date_conso}</p>
//         <p>Remarques : ${data.bouteilles_remarques}</p>
//         <p>ID Vin : ${data.id_vin}</p>
//         <p>Place : ${data.place}</p>
//         <p>Presence : ${data.presence}</p>`;

//     // Afficher le modal après avoir inséré les données
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// // Fonction pour fermer le modal
// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
// }








// // Assurez-vous que le DOM est chargé avant d'attacher des écouteurs d'événements
// document.addEventListener('DOMContentLoaded', function() {
//     const cercle = document.getElementById('cercle');
    
//     // Ajoutez un écouteur d'événements au clic sur le cercle
//     cercle.addEventListener('click', function() {
//         // Obtenez l'ID de la bouteille associée au cercle
//         const id_bouteilles = cercle.getAttribute('data-id-bouteilles');

//         // Vérifiez si l'ID de la bouteille est valide avant d'afficher le modal
//         if (id_bouteilles !== undefined && id_bouteilles !== null) {
//             showModal(id_bouteilles);
//         } else {
//             console.error('Erreur: ID de bouteille non disponible');
//         }
//     });
// });

// // Fonction pour afficher le modal
// function showModal(id_bouteilles) {
//     // Supprimez le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_bouteilles !== undefined) {
//                 showBouteillesModal(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showBouteillesModal(bouteillesData) {
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${bouteillesData.id_bouteilles}</p>
//             <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//             <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//             <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//             <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//             <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//             <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//             <p>ID Vin : ${bouteillesData.id_vin}</p>
//             <p>Place : ${bouteillesData.place}</p>
//             <p>Presence : ${bouteillesData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Ajoutez un événement pour fermer le modal en cliquant sur le bouton de fermeture
//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM:', modal);
// }


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;
    
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block'; // Afficher le modal
//     }
    
//     function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
//     }
    





// // Fonction pour afficher le modal
// function showModal(id_bouteilles) {
//     // Supprimez le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.id_bouteilles !== undefined) {
//                 showBouteillesModal(data);
//             } else {
//                 console.error('Erreur: données de bouteille incorrectes');
//             }
//         })
//         .catch(error => console.error('Erreur:', error));
// }

// // Fonction pour créer et afficher le modal avec les données reçues
// function showBouteillesModal(bouteillesData) {
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${bouteillesData.id_bouteilles}</p>
//             <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//             <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//             <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//             <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//             <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//             <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//             <p>ID Vin : ${bouteillesData.id_vin}</p>
//             <p>Place : ${bouteillesData.place}</p>
//             <p>Presence : ${bouteillesData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Ajoutez un événement pour fermer le modal en cliquant sur le bouton de fermeture
//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM:', modal);
// }

// // Fonction pour supprimer le modal
// function closeModal() {
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }






















// /* script-emplacement.js */

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_bouteilles');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);
//             if (data.length > 0) { // Assurez-vous que vous recevez au moins une bouteille
//                 showBouteillesModal(data);
//             } else {
//                 console.error('Aucune donnée de la bouteille trouvée pour cet ID');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// // function showModal(id_bouteilles) {
// //     console.log('showModal appelé avec l\'ID :', id_bouteilles);

// //     // Supprimer le modal précédent s'il existe
// //     closeModal();

// //     fetch(`http://localhost:3000/get/bouteilles`)
// //         .then(response => response.json())
// //         .then(data => {
// //             // console.log('Données reçues du serveur :', data);
// //             console.log('Données reçues du serveur :', data);


// //             if (data.status === 1) {
// //                 showBouteillesModal(data.bouteilles);
// //             } else {
// //                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
// //             }
// //         })
// //         .catch(error => console.error('Erreur :', error));
// // }

// function showBouteillesModal(bouteillesData) {
//     console.log('showBouteillesModal appelé avec les données :', bouteillesData);
    

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${bouteillesData.id_bouteilles}</p>
//             <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//             <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//             <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//             <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//             <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//             <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//             <p>ID Vin : ${bouteillesData.id_vin}</p>
//             <p>Place : ${bouteillesData.place}</p>
//             <p>Presence : ${bouteillesData.presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// // Définir les valeurs à mettre à jour
// const id_bouteilles = 100; // Remplacez cette valeur par l'ID de la bouteille que vous souhaitez mettre à jour
// const bouteilles_duree = 10;
// const bouteilles_millesime = 2014;
// const bouteilles_cote = 17;
// const bouteilles_prix = 100;
// const bouteilles_date_conso = NULL;
// const bouteilles_remarques = "Remise 20%";
// const id_vin = 16;

// // Effectuer la requête PUT
// fetch(`http://localhost:3000/update/bouteilles/${id_bouteilles}`, {
//     method: 'PUT',
//     headers: {
//         'Content-Type': 'application/json'
//     },
//     body: JSON.stringify({
//         id_bouteilles: id_bouteilles,
//         bouteilles_duree: bouteilles_duree,
//         bouteilles_millesime: bouteilles_millesime,
//         bouteilles_cote: bouteilles_cote,
//         bouteilles_prix: bouteilles_prix,
//         bouteilles_date_conso: bouteilles_date_conso,
//         bouteilles_remarques: bouteilles_remarques,
//         id_vin: id_vin
//     })
// }).then(response => {
//     if (!response.ok) {
//         throw new Error('La requête PUT a échoué');
//     }
//     return response.json();
// }).then(data => {
//     console.log('Réponse du serveur:', data);
// }).catch(error => {
//     console.error('Erreur lors de la requête PUT:', error);
// });


// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//     const bouteille = document.getElementById("bouteille");
//     const infosBouteille = document.getElementById("infos-bouteille");
//     // Sélectionnez votre rectangle (remplacez "rectangle" par l'ID approprié)
//     const rectangle = document.getElementById("rectangle");

// // Ajoutez un gestionnaire d'événements pour le clic sur le rectangle
//     rectangle.addEventListener("click", function() {
//         // Ajoutez ici votre logique d'animation
//         alert("Animation sur le rectangle !");
//     });


//     // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//     poignee.addEventListener("click", function() {
//         // Animation pour ouvrir la cave (exemple)
//         alert("La cave s'ouvre !");
//     });

//     // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//     bouteille.addEventListener("click", function() {
//         // Animation pour déplacer la bouteille (exemple)
//         bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//         bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//         // Afficher les informations sur la bouteille
//         infosBouteille.style.display = "block";
//         infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//     });

//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//             circle.addEventListener('mouseenter', showInfobulle);
//             circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_bouteilles = this.dataset.id_bouteilles;
//             showModal(id_bouteilles);
//         });
//     });
// });



// const socket = io('http://localhost:3000');

// socket.on('data', (data) => {
//     console.log();
//     // Sélectionner le corps du tableau
//     const tableBody = document.querySelector('#mesures-table tbody');

//     // Créer une nouvelle ligne pour les nouvelles données
//     const newRow = document.createElement('tr');

//     // Remplir la nouvelle ligne avec les données reçues
//     newRow.innerHTML = `
//         <td>${data.Humidite}</td>
//         <td>${data.Temperature}</td>
//         <td>${data.Time}</td>
//     `;
    


//     // Ajouter la nouvelle ligne au corps du tableau
//     tableBody.appendChild(newRow);
// });










// /* script-emplacement.js */

// function showInfobulle(event) {
//     // Récupérez l'ID de la bouteille à partir de l'attribut data
//     const bouteilleId = event.target.getAttribute('data-id_bouteilles');
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Mettez à jour le contenu de l'infobulle
//     infobulle.textContent = `ID de la bouteille: ${bouteilleId}`;
//     // Positionnez l'infobulle à côté du cercle
//     infobulle.style.left = `${event.pageX}px`;
//     infobulle.style.top = `${event.pageY}px`;
//     // Affichez l'infobulle
//     infobulle.style.display = 'block';
// }

// // Fonction pour masquer l'infobulle
// function hideInfobulle() {
//     // Obtenez l'infobulle
//     const infobulle = document.getElementById('infobulle');
//     // Cachez l'infobulle
//     infobulle.style.display = 'none';
// }


// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const poignee = document.getElementById("poignee");
//   const bouteille = document.getElementById("bouteille");
//   const infosBouteille = document.getElementById("infos-bouteille");

//   // Gestionnaire d'événement pour ouvrir la cave lorsque la poignée est cliquée
//   poignee.addEventListener("click", function() {
//     // Animation pour ouvrir la cave (exemple)
//     alert("La cave s'ouvre !");
//   });

//   // Gestionnaire d'événement pour déplacer la bouteille lorsque celle-ci est cliquée
//   bouteille.addEventListener("click", function() {
//     // Animation pour déplacer la bouteille (exemple)
//     bouteille.setAttribute("cx", "50"); // Nouvelle position en x
//     bouteille.setAttribute("cy", "100"); // Nouvelle position en y

//     // Afficher les informations sur la bouteille
//     infosBouteille.style.display = "block";
//     infosBouteille.innerHTML = "Nom: Vin Rouge<br/>Millésime: 2018<br/>Pays: France";
//   });

//     const circles = document.querySelectorAll('.wine-circle');
//     // const infobulle = document.getElementById('infobulle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function (event) {
//         circle.addEventListener('mouseenter', showInfobulle);
//         circle.addEventListener('mouseleave', hideInfobulle);

//             event.stopPropagation();  // Arrêter la propagation de l'événement pour éviter les clics multiples
//             const id_bouteilles = this.dataset.id_bouteilles;
//             showModal(id_bouteilles);
//         });
//     });
// });


// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showBouteillesModal(bouteillesData) {
//     console.log('showBouteillesModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <div class="modal-content">
//             <h2>Informations sur la BOUTEILLE</h2>
//             <p>ID : ${bouteillesData.id_bouteilles}</p>
//             <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//             <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//             <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//             <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//             <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//             <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//             <p>ID Vin : ${bouteillesData.id_vin}</p>
//             <p>PLACE : ${bouteillesData.Place}</p>
//             <p>Precense : ${bouteillesData.Presence}</p>
//             <button id="closeButton">Fermer</button>
//         </div>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     // const modalContent = document.querySelector('.modal-content');
//     // modalContent.style.position = 'fixed';
//     // modalContent.style.top = '50%';
//     // modalContent.style.left = '50%';
//     // modalContent.style.transform = 'translate(-50%, -50%)';
//     // modalContent.style.backgroundColor = 'white';
//     // modalContent.style.padding = '20px';
//     // modalContent.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }
// // // script-emplacement.js
// // // ...
// // const circleGeometry = new THREE.CircleGeometry(20, 32);
// // const circleMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });

// // function create3DCircle(x, y, z) {
// //     const circleMesh = new THREE.Mesh(circleGeometry, circleMaterial);
// //     circleMesh.position.set(x, y, z);
// //     scene.add(circleMesh);
// // }

// // // Utilisez la fonction create3DCircle pour chaque cercle existant
// // create3DCircle(50, 100, 0);
// // create3DCircle(100, 100, 0);
// // // ...







// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }















// /* script-emplacement.js */

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function () {
//             const id_bouteilles = this.dataset.id_bouteilles;
//             showModal(id_bouteilles);
//         });
//     });
// });

// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }


// function showBouteillesModal(bouteillesData) {
//     console.log('showBouteillesModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     // Ajoutez des logs pour déboguer les propriétés de bouteillesData
//     console.log('ID :', bouteillesData.id_bouteilles);
//     console.log('Durée :', bouteillesData.bouteilles_duree);
//     console.log('Millésime :', bouteillesData.bouteilles_millesime);
//     // ... Ajoutez des logs pour chaque propriété

//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${bouteillesData.id_bouteilles}</p>
//         <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//         <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//         <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//         <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//         <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//         <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//         <p>ID Vin : ${bouteillesData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     // Afficher la modal
//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }


// function showBouteillesModal(bouteillesData) {
//     console.log('showModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     console.log('showModal appelé');
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${bouteillesData.id_bouteilles}</p>
//         <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//         <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//         <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//         <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//         <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//         <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//         <p>ID Vin : ${bouteillesData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     modal.style.display = 'block';

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

































// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showBouteillesModal(bouteillesData) {
//     console.log('showModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     console.log('showModal appelé');
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${bouteillesData.id_bouteilles}</p>
//         <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//         <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//         <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//         <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//         <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//         <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//         <p>ID Vin : ${bouteillesData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const circles = document.querySelectorAll('.wine-circle');

//     circles.forEach(circle => {
//         circle.addEventListener('click', function () {
//             const id_bouteilles = this.dataset.id_bouteilles;
//             showModal(id_bouteilles);
//         });
//     });
// });


// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     // Supprimer la modal existante
//     closeModal();

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data && data.status === 1 && data.bouteilles) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }
// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }

// // ...

// const closeButton = modal.querySelector('#closeButton');
// closeButton.addEventListener('click', closeModal);
