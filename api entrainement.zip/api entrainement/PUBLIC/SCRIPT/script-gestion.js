
document.addEventListener('DOMContentLoaded', function () {
    const addWineButton = document.getElementById('addWineButtonVin');
    const myForm = document.getElementById('myForm');
    const myFormModifier = document.getElementById('myFormModifier');
    const searchInput = document.getElementById('searchInput');

    addWineButton.addEventListener('click', function () {
        myForm.classList.toggle('hidden');
    });

    myForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);

        fetch('http://localhost:3000/post/bouteilles', {
            method: 'POST',
            body: formData,
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            showModal(data);
            addDataToTableBouteilles(data);
        })
        .catch(error => console.error('Error:', error));
        console.error('Error:', error);
            // Affichez un message d'erreur à l'utilisateur
        alert('An error occurred while submitting data');
    });

    myFormModifier.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);

        fetch('http://localhost:3000/update/vin/' + formData.get('id_bouteilles_modif'), {
            method: 'PUT',
            body: formData,
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            showModal(data);
            addDataToTableBouteilles(data);
            filterTable(''); // Réinitialiser la recherche après modification
        })
        .catch(error => console.error('Error:', error));
    });

    fetch('http://localhost:3000/get/bouteilles')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        addDataToTableBouteilles(data);
    })
    .catch(error => console.error('Error:', error));

    searchInput.addEventListener('input', function () {
        const searchTerm = searchInput.value.toLowerCase();
        filterTable(searchTerm);
    });

    function filterTable(searchTerm) {
        const rows = document.querySelectorAll('#TabBouteillesBody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let rowContainsSearchTerm = false;

            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().includes(searchTerm)) {
                    rowContainsSearchTerm = true;
                }
            });

            row.style.display = rowContainsSearchTerm ? '' : 'none';
        });
    }

    function addDataToTableBouteilles(data) {
        const tableBody = document.getElementById('TabBouteillesBody');
        tableBody.innerHTML = '';

        // Vérifier si data est un tableau
        if (!Array.isArray(data)) {
            console.error('Error: Data is not an array');
            return;
        }

        data.forEach(bouteille => {
            const newRow = createTableRow(bouteille);
            tableBody.appendChild(newRow);
        });

        const deleteButtons = document.querySelectorAll('.deleteButton');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function () {
                const idToDelete = this.getAttribute('data-id');
                deleteBouteille(idToDelete);
            });
        });
    }

    function createTableRow(bouteille) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${bouteille.id_bouteilles}</td>
            <td>${bouteille.bouteilles_duree}</td>
            <td>${bouteille.bouteilles_millesime}</td>
            <td>${bouteille.bouteilles_cote}</td>
            <td>${bouteille.bouteilles_prix}</td>
            <td>${bouteille.bouteilles_date_conso}</td>
            <td>${bouteille.bouteilles_remarques}</td>
            <td>${bouteille.id_vin}</td>
            <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
        `;
        return newRow;
    }

    function showModal(data) {
        const modalDataDisplay = document.getElementById('modalDataDisplay');
        modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

        const modal = document.getElementById('myModal');
        modal.style.display = 'block';
    }

    function deleteBouteille(id) {
        fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
            method: 'DELETE',
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            const rowToDelete = document.getElementById(`row_${id}`);
            if (rowToDelete) {
                rowToDelete.remove();
            }
        })
        .catch(error => console.error('Error:', error));
    }
});


// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButton = document.getElementById('addWineButtonVin');
//     const myForm = document.getElementById('myForm');
//     const myFormModifier = document.getElementById('myFormModifier');
//     const searchInput = document.getElementById('searchInput');

//     addWineButton.addEventListener('click', function () {
//         myForm.classList.toggle('hidden');
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     myFormModifier.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/update/vin/' + formData.get('id_bouteilles_modif'), {
//             method: 'PUT',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//             filterTable(''); // Réinitialiser la recherche après modification
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/bouteilles')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         addDataToTableBouteilles(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     }
//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody');
//         tableBody.innerHTML = '';
    
//         // Vérifier si data est un tableau
//         if (!Array.isArray(data)) {
//             console.error('Error: Data is not an array');
//             return;
//         }
    
//         data.forEach(bouteille => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${bouteille.id_bouteilles}</td>
//                 <td>${bouteille.bouteilles_duree}</td>
//                 <td>${bouteille.bouteilles_millesime}</td>
//                 <td>${bouteille.bouteilles_cote}</td>
//                 <td>${bouteille.bouteilles_prix}</td>
//                 <td>${bouteille.bouteilles_date_conso}</td>
//                 <td>${bouteille.bouteilles_remarques}</td>
//                 <td>${bouteille.id_vin}</td>
//                 <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//             `;
//             tableBody.appendChild(newRow);
//         });
    
//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteBouteille(idToDelete);
//             });
//         });
//     }
    
//     // function addDataToTableBouteilles(data) {
//     //     const tableBody = document.getElementById('TabBouteillesBody');
//     //     tableBody.innerHTML = '';

//     //     data.forEach(bouteille => {
//     //         const newRow = createTableRow(bouteille);
//     //         tableBody.appendChild(newRow);
//     //     });

//     //     const deleteButtons = document.querySelectorAll('.deleteButton');
//     //     deleteButtons.forEach(button => {
//     //         button.addEventListener('click', function () {
//     //             const idToDelete = this.getAttribute('data-id');
//     //             deleteBouteille(idToDelete);
//     //         });
//     //     });
//     // }

//     function createTableRow(bouteille) {
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${bouteille.id_bouteilles}</td>
//             <td>${bouteille.bouteilles_duree}</td>
//             <td>${bouteille.bouteilles_millesime}</td>
//             <td>${bouteille.bouteilles_cote}</td>
//             <td>${bouteille.bouteilles_prix}</td>
//             <td>${bouteille.bouteilles_date_conso}</td>
//             <td>${bouteille.bouteilles_remarques}</td>
//             <td>${bouteille.id_vin}</td>
//             <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//         `;
//         return newRow;
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function deleteBouteille(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// });








// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButton = document.getElementById('addWineButtonVin');
//     const myForm = document.getElementById('myForm');
//     const myFormModifier = document.getElementById('myFormModifier');
//     const searchInput = document.getElementById('searchInput');

//     addWineButton.addEventListener('click', function () {
//         myForm.classList.toggle('hidden');
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     myFormModifier.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/update/vin/' + formData.get('id_bouteilles_modif'), {
//             method: 'PUT',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//             filterTable(''); // Réinitialiser la recherche après modification
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/bouteilles')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         addDataToTableBouteilles(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     }

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody');
//         tableBody.innerHTML = '';

//         data.forEach(bouteille => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${bouteille.id_bouteilles}</td>
//                 <td>${bouteille.bouteilles_duree}</td>
//                 <td>${bouteille.bouteilles_millesime}</td>
//                 <td>${bouteille.bouteilles_cote}</td>
//                 <td>${bouteille.bouteilles_prix}</td>
//                 <td>${bouteille.bouteilles_date_conso}</td>
//                 <td>${bouteille.bouteilles_remarques}</td>
//                 <td>${bouteille.id_vin}</td>
//                 <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//             `;
//             tableBody.appendChild(newRow);
//         });

//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteBouteille(idToDelete);
//             });
//         });
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function deleteBouteille(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// });



// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButton = document.getElementById('addWineButtonVin');
//     const myForm = document.getElementById('myForm');
//     const myFormModifier = document.getElementById('myFormModifier');
//     const searchInput = document.getElementById('searchInput');

//     addWineButton.addEventListener('click', function () {
//         myForm.classList.toggle('hidden');
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/bouteilles')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         addDataToTableBouteilles(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     }

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody');
//         tableBody.innerHTML = '';

//         data.forEach(bouteille => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${bouteille.id_bouteilles}</td>
//                 <td>${bouteille.bouteilles_duree}</td>
//                 <td>${bouteille.bouteilles_millesime}</td>
//                 <td>${bouteille.bouteilles_cote}</td>
//                 <td>${bouteille.bouteilles_prix}</td>
//                 <td>${bouteille.bouteilles_date_conso}</td>
//                 <td>${bouteille.bouteilles_remarques}</td>
//                 <td>${bouteille.id_vin}</td>
//                 <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//             `;
//             tableBody.appendChild(newRow);
//         });

//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteBouteille(idToDelete);
//             });
//         });
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function deleteBouteille(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// });



















// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButton = document.getElementById('addWineButtonVin');
//     const myForm = document.getElementById('myForm');
//     const myFormModifier = document.getElementById('myFormModifier');
//     const searchInput = document.getElementById('searchInput');

//     addWineButton.addEventListener('click', function () {
//         myForm.classList.toggle('hidden');
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/bouteilles')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         addDataToTableBouteilles(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody');
//         tableBody.innerHTML = '';

//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                     <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }

//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteBouteille(idToDelete);
//             });
//         });
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none';
//     }

//     function deleteBouteille(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// });











// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButton = document.getElementById('addWineButton');
//     const myForm = document.getElementById('myForm');
//     const myFormModifier = document.getElementById('myFormModifier');
//     const addWineForm = document.getElementById('addWineForm');
//     const searchInput = document.getElementById('searchInput');
//     myForm

//     addWineButton.addEventListener('click', function () {
//         addWineForm.classList.toggle('hidden');
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData,
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/bouteilles')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         addDataToTableBouteilles(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody');
//         tableBody.innerHTML = '';

//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                     <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }

//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteBouteille(idToDelete);
//             });
//         });
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none';
//     }

//     function deleteBouteille(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }
// });





// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
//     const searchInput = document.getElementById('searchInput');

//     // Fonction pour filtrer les résultats du tableau en fonction de la recherche
//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     }

//     const requestBody = {
//         id_bouteilles: id_bouteilles,
//         bouteilles_duree: bouteilles_duree,
//         bouteilles_millesime: bouteilles_millesime,
//         bouteilles_cote: bouteilles_cote,
//         bouteilles_prix: bouteilles_prix,
//         bouteilles_remarques: bouteilles_remarques,
//         id_vin: id_vin
//     };
    
//     if (bouteilles_date_conso !== null) {
//         requestBody.bouteilles_date_conso = bouteilles_date_conso;
//     }
    
//     fetch(`http://localhost:3000/update/bouteilles/${id_bouteilles}`, {
//         method: 'PUT',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(requestBody)
//     }).then(response => {
//         if (!response.ok) {
//             throw new Error('La requête PUT a échoué');
//         }
//         return response.json();
//     }).then(data => {
//         console.log('Réponse du serveur:', data);
//     }).catch(error => {
//         console.error('Erreur lors de la requête PUT:', error);
//     });
    

//     fetch('http://localhost:3000/get/bouteilles')
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//     addWineButtonbouteilles.addEventListener('click', function () {
//         myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData, // Utilisation directe de FormData
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     // Fonction pour mettre à jour une bouteille
// function updateBouteille(id, newData) {
//     fetch(`http://localhost:3000/update/bouteilles/${id}`, {
//         method: 'PUT',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(newData),
//     })
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     })
//     .then(data => {
//         console.log(data);
//         // Mettre à jour les données dans la ligne du tableau côté client si la mise à jour est réussie
//         if (data.status === 1) {
//             // Ici, vous pouvez mettre à jour les données dans le tableau avec les nouvelles données
//             console.log('Bouteille mise à jour avec succès');
//         } else {
//             console.error('Erreur lors de la mise à jour de la bouteille');
//         }
//     })
//     .catch(error => console.error('Error:', error));
// }

// // Ajoutez un événement d'écouteur à chaque bouton "Modifier"
// const editButtons = document.querySelectorAll('.editButton');
// editButtons.forEach(button => {
//     button.addEventListener('click', function () {
//         const idToUpdate = this.getAttribute('data-id');
//         // Ici, vous devez implémenter une logique pour récupérer les nouvelles données de l'utilisateur
//         // et les envoyer à la fonction updateBouteille
//         // Par exemple, vous pouvez afficher un formulaire modal pour que l'utilisateur entre les nouvelles données
//         // ou utiliser d'autres méthodes d'interaction utilisateur pour collecter les nouvelles données
//         const newData = {
//             // Définissez ici les nouvelles données à mettre à jour
//         };
//         updateBouteille(idToUpdate, newData);
//     });
// });

     

//     // Fonction pour supprimer une ligne du tableau en utilisant son ID
//     function deleteTableRow(id) {
//         fetch(`http://localhost:3000/delete/bouteilles/${id}`, {
//             method: 'DELETE',
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             // Supprimer la ligne du tableau côté client si la suppression est réussie
//             const rowToDelete = document.getElementById(`row_${id}`);
//             if (rowToDelete) {
//                 rowToDelete.remove();
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     }

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody'); // Récupérer l'élément tbody du tableau
    
//         // Vider le contenu du tableau avant d'ajouter de nouvelles données
//         tableBody.innerHTML = '';

//         // Itérer sur les propriétés de l'objet data
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.setAttribute('id', `row_${bouteille.id_bouteilles}`); // Définir un ID unique pour chaque ligne
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                     <td><button class="deleteButton" data-id="${bouteille.id_bouteilles}">Supprimer</button></td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }

//         // Attacher un écouteur d'événements à chaque bouton de suppression
//         const deleteButtons = document.querySelectorAll('.deleteButton');
//         deleteButtons.forEach(button => {
//             button.addEventListener('click', function () {
//                 const idToDelete = this.getAttribute('data-id');
//                 deleteTableRow(idToDelete); // Appeler la fonction de suppression avec l'ID correspondant
//             });
//         });
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none';
//     }
// });















// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
//     const searchInput = document.getElementById('searchInput');

//     // Fonction pour filtrer les résultats du tableau en fonction de la recherche
//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     }

//     fetch('http://localhost:3000/get/bouteilles')
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//     addWineButtonbouteilles.addEventListener('click', function () {
//         myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: formData, // Utilisation directe de FormData
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody'); // Récupérer l'élément tbody du tableau
    
//         // Vider le contenu du tableau avant d'ajouter de nouvelles données
//         tableBody.innerHTML = '';

//         // Itérer sur les propriétés de l'objet data
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }
//     }

//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';
//     }

//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none';
//     }
// });













// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
//     const searchInput = document.getElementById('searchInput');
    

//     // Fonction pour filtrer les résultats du tableau en fonction de la recherche
//     function filterTable(searchTerm) {
//         const rows = document.querySelectorAll('#TabBouteillesBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     }

//     fetch('http://localhost:3000/get/bouteilles/id') // Assurez-vous que l'URL correspond à l'endpoint de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//     addWineButtonbouteilles.addEventListener('click', function () {
//         myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });
    
//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         filterTable(searchTerm);
//     });
   

//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody'); // Récupérer l'élément tbody du tableau
    
//         // Itérer sur les propriétés de l'objet data
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }
//     }
    
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     document.addEventListener('DOMContentLoaded', function () {
//         const myFormModifier = document.getElementById('myFormModifier'); // Sélectionnez le formulaire de modification
//         const deleteIcons = document.querySelectorAll('.delete-icon'); // Sélectionnez les icônes de suppression pour afficher le formulaire de modification
    
//         // Ajoutez un gestionnaire d'événements à chaque icône de suppression
//         deleteIcons.forEach(icon => {
//             icon.addEventListener('click', function () {
//                 // Afficher le formulaire de modification correspondant à la ligne
//                 const myFormModifier = this.parentNode.parentNode.querySelector('.myFormModifier'); // Sélectionnez le formulaire de modification correspondant à l'icône de suppression cliquée
//                 myFormModifier.style.display = 'block';
//                 myFormModifier.style.display = 'block';
//             });
//         });
    
//         // Gestionnaire d'événements pour le soumission du formulaire de modification
//         myFormModifier.addEventListener('submit', function (e) {
//             e.preventDefault();
    
//             const formData = new FormData(this);
    
//             fetch('http://localhost:3000/update/bouteilles', {
//                 method: 'PUT', // Utilisez PUT pour mettre à jour les données
//                 body: JSON.stringify(Object.fromEntries(formData.entries())),
//                 headers: {
//                     'Content-Type': 'application/json'
//                 }
//             })
//             .then(response => response.json())
//             .then(data => {
//                 console.log(data);
//                 showModal(data);
//                 // addDataToTableBouteilles(data); 
//             })
//             .catch(error => console.error('Error:', error));
//         });
//     });
    
// });


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
//     const searchInput = document.getElementById('searchInput');

//     fetch('http://localhost:3000/get/bouteilles') // Assurez-vous que l'URL correspond à l'endpoint de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//     addWineButtonbouteilles.addEventListener('click', function () {
//         myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         console.log(formData)

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });
//      // Ajouter un écouteur d'événements pour la barre de recherche
//      searchInput.addEventListener('input', function () {
//         const searchTerm = searchInput.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });
   


//     function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteillesBody'); // Récupérer l'élément tbody du tableau
    
//         // Itérer sur les propriétés de l'objet data
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const bouteille = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${bouteille.id_bouteilles}</td>
//                     <td>${bouteille.bouteilles_duree}</td>
//                     <td>${bouteille.bouteilles_millesime}</td>
//                     <td>${bouteille.bouteilles_cote}</td>
//                     <td>${bouteille.bouteilles_prix}</td>
//                     <td>${bouteille.bouteilles_date_conso}</td>
//                     <td>${bouteille.bouteilles_remarques}</td>
//                     <td>${bouteille.id_vin}</td>
//                 `;
//                 tableBody.appendChild(newRow);
//             }
//         }
//     }
    

    

//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }




// function addDataToTableBouteilles(data) {
    //     const tableBody = document.getElementById('TabBouteillesBody'); // Récupérer l'élément tbody du tableau
    
    //     // Boucler à travers les données et les ajouter au tableau
    //     data.forEach(bouteille => {
    //         const newRow = document.createElement('tr');
    //         newRow.innerHTML = `
    //             <td>${bouteille.bouteilles_duree}</td>
    //             <td>${bouteille.bouteilles_millesime}</td>
    //             <td>${bouteille.bouteilles_cote}</td>
    //             <td>${bouteille.bouteilles_prix}</td>
    //             <td>${bouteille.bouteilles_date_conso}</td>
    //             <td>${bouteille.bouteilles_remarques}</td>
    //             <td>${bouteille.id_vin}</td>
    //         `;
    //         tableBody.appendChild(newRow);
    //     });
    // }
    

    // function addDataToTableBouteilles(data) {
    //     const tableBody = document.getElementById('TabBouteillesBody');
    //     console.log(data); // Vérifier les données reçues depuis le serveur
    
    //     if (data && data.data) {
    //         const formDataDisplay = document.getElementById('TabBouteillesBody').getElementsByTagName('tbody')[0];
    //         const newRow = document.createElement('tr');
    //         newRow.innerHTML = `
    //             <td>${data.data.bouteilles_duree}</td>
    //             <td>${data.data.bouteilles_millesime}</td>
    //             <td>${data.data.bouteilles_cote}</td>
    //             <td>${data.data.bouteilles_prix}</td>
    //             <td>${data.data.bouteilles_date_conso}</td>
    //             <td>${data.data.bouteilles_remarques}</td>
    //             <td>${data.data.id_vin}</td>
    //         `;
    //         formDataDisplay.appendChild(newRow);
    //     } else {
    //         console.error('Erreur : Données non valides');
    //     }
    // }























// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
    
//     fetch('http://localhost:3000/get/bouteilles') // Assurez-vous que l'URL correspond à l'endpoint de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//     addWineButtonbouteilles.addEventListener('click', function () {
//         myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });

// function addDataToTableBouteilles(data) {
//     console.log(data); // Vérifier les données reçues depuis le serveur
    
//     if (data && data.length > 0) { // Vérifiez si des données sont présentes dans le tableau
//         const tableBody = document.getElementById('TabBouteillesBody');
        
//         data.forEach(item => { // Itérer sur chaque élément du tableau
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${item.bouteilles_duree}</td>
//                 <td>${item.bouteilles_millesime}</td>
//                 <td>${item.bouteilles_cote}</td>
//                 <td>${item.bouteilles_prix}</td>
//                 <td>${item.bouteilles_date_conso}</td>
//                 <td>${item.bouteilles_remarques}</td>
//                 <td>${item.id_vin}</td>
//             `;
//             tableBody.appendChild(newRow);
//         });
//     } else {
        
//         console.error('Erreur : Données non valides ou tableau vide');
//     }
// }


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }


























// document.addEventListener('DOMContentLoaded', function () {
//     const addWineButtonbouteilles = document.getElementById('addWineButtonbouteilles');
//     const myForm = document.getElementById('myForm');
//     fetch('http://localhost:3000/get/bouteilles') // Assurez-vous que l'URL correspond à l'endpoint de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableBouteilles(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//         addWineButtonbouteilles.addEventListener('click', function () {
//             myForm.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//         });
//     }
//         function addDataToTableBouteilles(data) {
//         const tableBody = document.getElementById('TabBouteilles'); // Récupérer l'élément tbody du tableau

//         // Boucler à travers les données et les ajouter au tableau
//         data.forEach(bouteille => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${bouteille.bouteilles_duree}</td>
//                 <td>${bouteille.bouteilles_millesime}</td>
//                 <td>${bouteille.bouteilles_cote}</td>
//                 <td>${bouteille.bouteilles_prix}</td>
//                 <td>${bouteille.bouteilles_date_conso}</td>
//                 <td>${bouteille.bouteilles_remarques}</td>
//                 <td>${bouteille.id_vin}</td>
//             `;
//             tableBody.appendChild(newRow);
//         });
//     }
// document.addEventListener('DOMContentLoaded', function () {
//     const myForm = document.getElementById('myForm');

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         console.log(formData)

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     function addDataToTableBouteilles(data) {
//         console.log(data); // Vérifier les données reçues depuis le serveur
    
//         if (data && data.data) {
//             const formDataDisplay = document.getElementById('TabBouteillesBody').getElementsByTagName('tbody')[0];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${data.data.bouteilles_duree}</td>
//                 <td>${data.data.bouteilles_millesime}</td>
//                 <td>${data.data.bouteilles_cote}</td>
//                 <td>${data.data.bouteilles_prix}</td>
//                 <td>${data.data.bouteilles_date_conso}</td>
//                 <td>${data.data.bouteilles_remarques}</td>
//                 <td>${data.data.id_vin}</td>
//             `;
//             formDataDisplay.appendChild(newRow);
//         } else {
//             console.error('Erreur : Données non valides');
//         }
//     }

//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }


























// document.addEventListener('DOMContentLoaded', function () {
//     const myForm = document.getElementById('myForm');

//     myForm.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableBouteilles(data); 
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     function addDataToTableBouteilles(data) {
//         console.log(data);
//         const formDataDisplay = document.getElementById('TabBouteilles').getElementsByTagName('tbody')[0]; // Récupérer l'élément tbody
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${data.data.bouteilles_duree}</td>
//             <td>${data.data.bouteilles_millesime}</td>
//             <td>${data.data.bouteilles_cote}</td>
//             <td>${data.data.bouteilles_prix}</td>
//             <td>${data.data.bouteilles_date_conso}</td>
//             <td>${data.data.bouteilles_remarques}</td>
//             <td>${data.data.id_vin}</td>
//         `;
//         formDataDisplay.appendChild(newRow);
//     }

//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });











































// document.addEventListener('DOMContentLoaded', function () {
//     const form = document.getElementById('myForm');

//     form.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Afficher les données dans le modal
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Gestionnaire d'événements pour le bouton de suppression
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         // Utiliser la méthode DELETE pour supprimer les données
//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher un message de suppression dans #dataDisplay
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });

// document.addEventListener('DOMContentLoaded', function () {
//     const form = document.getElementById('Formvin');

//     form.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Afficher les données dans le modal
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Gestionnaire d'événements pour le bouton de suppression
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         // Utiliser la méthode DELETE pour supprimer les données
//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher un message de suppression dans #dataDisplay
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     // Afficher le modal
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }










































// document.addEventListener('DOMContentLoaded', function () {
//     const form = document.getElementById('myForm');

//     form.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Afficher les données dans le modal
//             const modalDataDisplay = document.getElementById('modalDataDisplay');
//             modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//             // Afficher le modal
//             const modal = document.getElementById('myModal');
//             modal.style.display = 'block';
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Gestionnaire d'événements pour le bouton de mise à jour
//     document.getElementById('updateButton').addEventListener('click', function () {
//         const updateId = document.getElementById('updateId').value;
//         const bouteilles_duree = document.getElementById('bouteilles_duree').value;
//         const bouteilles_millesime = document.getElementById('bouteilles_millesime').value;
//         const bouteilles_cote = document.getElementById('bouteilles_cote').value;
//         const bouteilles_prix = document.getElementById('bouteilles_prix').value;
//         const bouteilles_date_conso = document.getElementById('bouteilles_date_conso').value;
//         const bouteilles_remarques = document.getElementById('bouteilles_remarques').value;
//         const id_vin = document.getElementById('id_vin').value;

//         // Utiliser la méthode PUT pour mettre à jour les données
//         fetch(`http://localhost:3000/update/bouteilles/${updateId}`, {
//             method: 'PUT',
//             body: JSON.stringify({
//                 bouteilles_duree,
//                 bouteilles_millesime,
//                 bouteilles_cote,
//                 bouteilles_prix,
//                 bouteilles_date_conso,
//                 bouteilles_remarques,
//                 id_vin
//             }),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher les données mises à jour dans #dataDisplay
//             const dataDisplay = document.getElementById('dataDisplay');
//             dataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Gestionnaire d'événements pour le bouton de suppression
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         // Utiliser la méthode DELETE pour supprimer les données
//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//             // Aucun besoin d'ajouter le corps de la requête DELETE
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher un message de suppression dans #dataDisplay
//             const dataDisplay = document.getElementById('dataDisplay');
//             dataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Fonction pour fermer le modal
//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none';
//     }
// });

// Fonction pour fermer le modal
// function closeModal() {
//     const modal = document.getElementById('myModal');
//     setTimeout(() => {
//         modal.style.display = 'none';
//     }, 100);
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const form = document.getElementById('myForm');

//     form.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteilles', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Afficher les données dans le modal
//             const modalDataDisplay = document.getElementById('modalDataDisplay');
//             modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//             // Afficher le modal
//             const modal = document.getElementById('myModal');
//             modal.style.display = 'block';
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Gestionnaire d'événements pour le bouton de mise à jour
//     document.getElementById('updateButton').addEventListener('click', function () {
//         const updateId = document.getElementById('updateId').value;
//         const bouteilles_duree = document.getElementById('bouteilles_duree').value;
//         const bouteilles_millesime = document.getElementById('bouteilles_millesime').value;
//         const bouteilles_cote = document.getElementById('bouteilles_cote').value;
//         const bouteilles_prix = document.getElementById('bouteilles_prix').value;
//         const bouteilles_date_conso = document.getElementById('bouteilles_date_conso').value;
//         const bouteilles_remarques = document.getElementById('bouteilles_remarques').value;
//         const id_vin = document.getElementById('id_vin').value;

//         // Utiliser la méthode PUT pour mettre à jour les données
//         fetch(`http://localhost:3000/update/bouteilles/${updateId}`, {
//             method: 'PUT',
//             body: JSON.stringify({
//                 bouteilles_duree,
//                 bouteilles_millesime,
//                 bouteilles_cote,
//                 bouteilles_prix,
//                 bouteilles_date_conso,
//                 bouteilles_remarques,
//                 id_vin
//             }),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher les données mises à jour dans #dataDisplay
//             const dataDisplay = document.getElementById('dataDisplay');
//             dataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;
//         })
//         .catch(error => console.error('Error:', error));
//     });

//        // Gestionnaire d'événements pour le bouton de suppression
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         // Utiliser la méthode DELETE pour supprimer les données
//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Ajouter ici le code pour afficher un message de suppression dans #dataDisplay
//             const modalDataDisplay = document.getElementById('modalDataDisplay');
//             dataDisplay.innerHTML = `<h2>Suppression réussie</h2>`;
            
//             // Fermer le modal après la suppression
//             closeModal();
//         })
//         .catch(error => console.error('Error:', error));
//     });
// });


// function showModal(id_bouteilles) {
//     console.log('showModal appelé avec l\'ID :', id_bouteilles);

//     fetch(`http://localhost:3000/get/bouteilles/${id_bouteilles}`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('Données reçues du serveur :', data);

//             if (data.status === 1) {
//                 showBouteillesModal(data.bouteilles);
//             } else {
//                 console.error('Erreur lors de la récupération des données de la BOUTEILLE');
//             }
//         })
//         .catch(error => console.error('Erreur :', error));
// }

// function showBouteillesModal(bouteillesData) {
//     console.log('showModal appelé avec les données :', bouteillesData);

//     if (!bouteillesData || bouteillesData.id_bouteilles === undefined) {
//         console.error('Données de bouteille incorrectes');
//         return;
//     }

//     console.log('showModal appelé');
//     const modal = document.createElement('div');
//     modal.classList.add('modal');
//     modal.innerHTML = `
//         <h2>Informations sur la BOUTEILLE</h2>
//         <p>ID : ${bouteillesData.id_bouteilles}</p>
//         <p>Durée : ${bouteillesData.bouteilles_duree}</p>
//         <p>Millésime : ${bouteillesData.bouteilles_millesime}</p>
//         <p>Cote : ${bouteillesData.bouteilles_cote}</p>
//         <p>Prix : ${bouteillesData.bouteilles_prix}</p>
//         <p>Date de consommation : ${bouteillesData.bouteilles_date_conso}</p>
//         <p>Remarques : ${bouteillesData.bouteilles_remarques}</p>
//         <p>ID Vin : ${bouteillesData.id_vin}</p>
//         <button id="closeButton">Fermer</button>
//     `;
//     document.body.appendChild(modal);

//     const closeButton = modal.querySelector('#closeButton');
//     closeButton.addEventListener('click', closeModal);

//     console.log('Modal ajoutée au DOM :', modal);
// }

// function closeModal() {
//     console.log('closeModal appelé');
//     const modal = document.querySelector('.modal');
//     if (modal) {
//         modal.remove();
//     }
// }