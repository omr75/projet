function closeModal() {
    const modal = document.getElementById('myModal');
    if (modal) {
        modal.style.display = 'none';
    } else {
        console.error('Element modal not found.');
    }
}

function showModal(id_vin, data) {
    console.log('showModal appelé avec les données :', data);

    // Supprimer le modal précédent s'il existe
    closeModal();

    // Vérifier si les données contiennent un ID de vin valide
    if (data && data.id_vin) {
        // Afficher les données du vin dans le modal
        const modalDataDisplay = document.getElementById('modalDataDisplay');
        modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

        // Afficher le modal
        const modal = document.getElementById('myModal');
        modal.style.display = 'block';

        // Mettre à jour la couleur du cercle SVG avec la couleur du vin
        const color = data.color;
        updateColorCircle(id_vin, color);
    } else {
        console.error('ID du vin non défini dans les données.');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const colorOptions = document.querySelectorAll('.color-option');
    let selectedColor = ''; // Variable pour stocker la couleur sélectionnée
    const socket = io();

    colorOptions.forEach(option => {
        option.addEventListener('click', function(event) {
            const color = event.target.getAttribute('fill');
            selectedColor = color; // Mettre à jour la variable de couleur sélectionnée
            console.log('Couleur sélectionnée :', selectedColor);
    
            // Mettre à jour la valeur de l'input hidden avec la couleur sélectionnée
            document.getElementById('vin_couleur_input').value = selectedColor;
        });
    });

    const searchInputVin = document.getElementById('searchInputVin');

    //  Gestion de la recherche de vin
    searchInputVin.addEventListener('input', function () {
        const searchTerm = searchInputVin.value.toLowerCase();
        const rows = document.querySelectorAll('#tableVinBody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let rowContainsSearchTerm = false;

            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().includes(searchTerm)) {
                    rowContainsSearchTerm = true;
                }
            });

            row.style.display = rowContainsSearchTerm ? '' : 'none';
        });
    });

    // Gestion de la soumission du formulaire d'ajout de vin
    const formVin = document.getElementById('formvin');
    document.getElementById('vin_couleur').value = selectedColor;
    console.log('Valeur de vin_couleur mise à jour :', selectedColor);

    formVin.addEventListener('submit', function (e) {
        e.preventDefault(); // Empêche le rechargement de la page

        // Récupération des données du formulaire
        const formData = new FormData(this);

        // Récupérer la couleur sélectionnée
        formData.append('vin_couleur', selectedColor);

        console.log("Couleur sélectionnée à envoyer au serveur :", selectedColor);
        socket.emit('colorUpdated', { color: selectedColor });

        console.log('Données envoyées avec la requête fetch :', JSON.stringify(Object.fromEntries(formData.entries())));

        fetch('http://localhost:3000/post/bouteillesvin', {
            method: 'POST',
            body: JSON.stringify(Object.fromEntries(formData.entries())),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            console.log('Réponse du serveur :', response);
            return response.json();
        })
        .then(data => {
            console.log('Données reçues du serveur :', data);
            showModal(data.data.id_vin, data.data); // Passer les données au lieu de data
        })
        
        .catch(error => console.error('Error:', error));
    });

    // Gestion de la soumission du formulaire de modification de vin
    const formVinModif = document.getElementById('formvinModif');
    if (formVinModif) {
        formVinModif.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const idVinModif = formData.get('id_vin_modif');

            fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
                method: 'PUT',
                body: JSON.stringify(Object.fromEntries(formData.entries())),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                updateDataInTableVin(data);
                showModal(data.id_vin, data);
            })
            .catch(error => console.error('Error:', error));
        });
    }

    // Récupérer les données des vins et les afficher dans le tableau
    fetch('http://localhost:3000/get/vin')
    .then(response => response.json())
    .then(data => {
        addDataToTableVin(data);
    })
    .catch(error => console.error('Error:', error));
});

function addDataToTableVin(data) {
    const tableVin = document.getElementById('tableVinBody');

    // Effacer le contenu actuel du tableau
    tableVin.innerHTML = '';

    // Vérifier si data est un objet ou un tableau
    if (typeof data === 'object' && !Array.isArray(data)) {
        // Si data est un objet, ajouter chaque entrée dans le tableau
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const vin = data[key];
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                    <td>${vin.id_vin}</td>
                    <td>${vin.vin_couleur}</td>
                    <td>${vin.vin_region}</td>
                    <td>${vin.vin_appellation}</td>
                    <td>${vin.vin_terroir}</td>
                    <td>${vin.vin_domaine}</td>
                `;
                tableVin.appendChild(newRow);
            }
        }
    } else if (Array.isArray(data)) {
        // Si data est un tableau, ajouter chaque élément dans le tableau
        data.forEach(vin => {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${vin.id_vin}</td>
                <td>${vin.vin_couleur}</td>
                <td>${vin.vin_region}</td>
                <td>${vin.vin_appellation}</td>
                <td>${vin.vin_terroir}</td>
                <td>${vin.vin_domaine}</td>
            `;
            tableVin.appendChild(newRow);
        });
    } else {
        console.error('Error: Data is not an object or array.');
    }
}

function updateDataInTableVin(data) {
    const idVin = data.id_vin; // Récupérer l'ID du vin de la réponse
    const rows = document.querySelectorAll('#tableVinBody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const vinId = cells[0].textContent;

        if (vinId === idVin) {
            cells[1].textContent = data.vin_couleur;
            cells[2].textContent = data.vin_region;
            cells[3].textContent = data.vin_appellation;
            cells[4].textContent = data.vin_terroir;
            cells[5].textContent = data.vin_domaine;
        }
    });
}

// Fonction pour ouvrir le formulaire d'ajout de vin
function openAddForm() {
    document.getElementById("formvin").classList.remove("hidden");
}

// Fonction pour ouvrir le formulaire de modification de vin
function openEditForm() {
    document.getElementById("formvinModif").classList.remove("hidden");
}

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     if (modal) {
//         modal.style.display = 'none';
//     } else {
//         console.error('Element modal not found.');
//     }
// }
// // function showModal(id_vin, data) {
// //     console.log('showModal appelé avec les données :', data);

// //     // Supprimer le modal précédent s'il existe
// //     closeModal();

// //     // Vérifier si les données contiennent un ID de vin valide
// //     if (data && data.id_vin) {
// //         // Afficher les données du vin dans le modal
// //         const modalDataDisplay = document.getElementById('modalDataDisplay');
// //         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

// //         // Afficher le modal
// //         const modal = document.getElementById('myModal');
// //         modal.style.display = 'block';

// //         // Mettre à jour la couleur du cercle SVG avec la couleur du vin
// //         const color = data.vin_couleur;
// //         updateColorCircle(id_vin, color);
// //     } else {
// //         console.error('ID du vin non défini dans les données.');
// //     }
// // }

// function showModal(id_vin) {
//     console.log('showModal appelé avec les données :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     // Vérifier si les données contiennent un ID de vin valide
//     if (data && data.id_vin) {
//         // Récupérer l'ID du vin depuis les données
//         const id_vin = data.id_vin;

//         // Afficher les données du vin dans le modal
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         // Afficher le modal
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block';

//         // Mettre à jour la couleur du cercle SVG avec la couleur du vin
//         const color = data.vin_couleur;
//         updateColorCircle(id_vin, color);
//     } else {
//         console.error('ID du vin non défini dans les données.');
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const colorOptions = document.querySelectorAll('.color-option');
//     let selectedColor = ''; // Variable pour stocker la couleur sélectionnée
//     const socket = io();

//     colorOptions.forEach(option => {
//         option.addEventListener('click', function(event) {
//             const color = event.target.getAttribute('fill');
//             selectedColor = color; // Mettre à jour la variable de couleur sélectionnée
//             console.log('Couleur sélectionnée :', selectedColor);
    
//             // Mettre à jour la valeur de l'input hidden avec la couleur sélectionnée
//             document.getElementById('vin_couleur_input').value = selectedColor;
//         });
//     });
    

//     const searchInputVin = document.getElementById('searchInputVin');
//     // // Récupérer tous les cercles SVG et leur ajouter un écouteur d'événements
//     // const circles = document.querySelectorAll('#vin_couleur circle');
//     // circles.forEach(circle => {
//     //     circle.addEventListener('click', function () {
//     //         // Récupérer la couleur du cercle SVG et appeler selectColor
//     //         const color = circle.getAttribute('fill');
//     //         selectColor(color);
//     //     });
//     // });

//     // socket.on('connect', function() {
//     //     console.log('Connecté au serveur Socket.IO');
//     // });
    
//     //  Gestion de la recherche de vin
//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     });

    
//     // Gestion de la soumission du formulaire d'ajout de vin
//     const formVin = document.getElementById('formvin');
//     document.getElementById('vin_couleur').value = selectedColor;
//     console.log('Valeur de vin_couleur mise à jour :', selectedColor);

//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault(); // Empêche le rechargement de la page

//         // Récupération des données du formulaire
//         const formData = new FormData(this);

//         // Récupérer la couleur sélectionnée
//         // const selectedColor = document.getElementById('vin_couleur').value;



//         // Ajout de la couleur sélectionnée aux données du formulaire
//         formData.append('vin_couleur', selectedColor);

//                 // Juste avant l'émission de la couleur
//         console.log("Couleur sélectionnée à envoyer au serveur :", selectedColor);
//         socket.emit('colorUpdated', { color: selectedColor });

//         console.log('Données envoyées avec la requête fetch :', JSON.stringify(Object.fromEntries(formData.entries())));

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })

//         .then(response => {
//             console.log('Réponse du serveur :', response);
//             return response.json();
//         })
//         .then(data => {
//             console.log('Données reçues du serveur :', data);
//             showModal(id_vin, data);
//         })
//         .catch(error => console.error('Error:', error));
        
//     });


    
//     // Gestion de la soumission du formulaire de modification de vin
//     const formVinModif = document.getElementById('formvinModif');
//     if (formVinModif) {
//         formVinModif.addEventListener('submit', function (e) {
//             e.preventDefault();

//             const formData = new FormData(this);
//             const idVinModif = formData.get('id_vin_modif');

//             fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//                 method: 'PUT',
//                 body: JSON.stringify(Object.fromEntries(formData.entries())),
//                 headers: {
//                     'Content-Type': 'application/json'
//                 }
//             })
//             .then(response => response.json())
//             // Après avoir reçu la réponse de la modification du vin
//             .then(data => {
//                 // Récupérer la couleur du vin modifié depuis les données
//                 // const vinColor = data.vin_couleur;

//                 // // Mettre à jour l'attribut data-color du cercle SVG correspondant au vin modifié
//                 // const modifiedCircle = document.querySelector(`[data-id_vin="${data.id_vin}"]`);
//                 // modifiedCircle.setAttribute('data-color', vinColor);

//                 // Afficher les données reçues dans une modal
//                      console.log(data);
//                 updateDataInTableVin(data);
//                 showModal(data.id_vin); // Passer l'ID du vin à la fonction showModal

// })

//             // .then(data => {

//             // })
//             .catch(error => console.error('Error:', error));
//         });
//     }

//     // Récupérer les données des vins et les afficher dans le tableau
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     // Effacer le contenu actuel du tableau
//     tableVin.innerHTML = '';

//     // Vérifier si data est un objet ou un tableau
//     if (typeof data === 'object' && !Array.isArray(data)) {
//         // Si data est un objet, ajouter chaque entrée dans le tableau
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const vin = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${vin.id_vin}</td>
//                     <td>${vin.vin_couleur}</td>
//                     <td>${vin.vin_region}</td>
//                     <td>${vin.vin_appellation}</td>
//                     <td>${vin.vin_terroir}</td>
//                     <td>${vin.vin_domaine}</td>
//                 `;
//                 tableVin.appendChild(newRow);
//             }
//         }
//     } else if (Array.isArray(data)) {
//         // Si data est un tableau, ajouter chaque élément dans le tableau
//         data.forEach(vin => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         });
//     } else {
//         console.error('Error: Data is not an object or array.');
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin; // Récupérer l'ID du vin de la réponse
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;

//             // Ajoutez des console.log pour afficher les données mises à jour
//             console.log('Données mises à jour :', data);
//         }
//     });
// }

// // Fonction pour ouvrir le formulaire d'ajout de vin
// function openAddForm() {
//     document.getElementById("formvin").classList.remove("hidden");
// }

// // Fonction pour ouvrir le formulaire de modification de vin
// function openEditForm() {
//     document.getElementById("formvinModif").classList.remove("hidden");
// }


// Modifier la fonction showModal pour accepter l'ID du vin comme argument
// function showModal(id_vin) {
//     console.log('showModal appelé avec l\'ID :', id_vin);

//     // Supprimer le modal précédent s'il existe
//     closeModal();

//     // Vérifier si l'ID du vin est défini
//     if (id_vin !== undefined) {
//         // Envoyer une requête fetch pour récupérer les données du vin avec l'ID spécifié
//         fetch(`http://localhost:3000/get/vin/${id_vin}`)
//             .then(response => response.json())
//             .then(data => {
//                 console.log('Données reçues du serveur :', data);
//                 // Vérifier si les données ont été récupérées avec succès
//                 if (data.status === 1) {
//                     // Extraire la couleur du vin à partir des données reçues
//                     const color = data.data.vin_couleur;

//                     // Mettre à jour la couleur du cercle SVG avec la couleur du vin
//                     updateColorCircle(id_vin, color);

//                     // Si les données sont récupérées avec succès, afficher la modal avec les données du vin
//                     showBouteillesModal(data.data); // Utilisez data.data car la réponse contient un objet "data" avec les données du vin
//                 } else {
//                     console.error('Erreur lors de la récupération des données du VIN');
//                     // Gérer l'erreur de récupération des données du vin
//                 }
//             })
//             .catch(error => console.error('Erreur :', error));
//     } else {
//         console.error('ID du vin non défini');
//         // Gérer le cas où l'ID du vin n'est pas défini
//     }
// }

// document.addEventListener('DOMContentLoaded', function () {

//     // Assurez-vous que la connexion Socket.IO est établie
//     var socket = io();
//     const searchInputVin = document.getElementById('searchInputVin');


//     socket.on('connect', function() {
//         console.log('Connecté au serveur Socket.IO');
//     });
//     //  Gestion de la recherche de vin
//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     });

//     // Gestion de la soumission du formulaire d'ajout de vin
//     const formVin = document.getElementById('formvin');
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault(); // Empêche le rechargement de la page

//         // Récupération des données du formulaire
//         const formData = new FormData(this);

//         // Envoi des données au serveur
//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             // Affichage des données reçues dans une modal
//             console.log(data);
//             showModal(data);
//             // Mise à jour de la couleur du cercle SVG si l'ajout de la bouteille est réussi
//             if (data && data.status === 1 && data.data && data.data.id_vin) {
//                 updateCircleColor(data.data.id_vin, socket);
//             } else {
//                 console.error('Erreur lors de l\'ajout de la bouteille :', data.status_message);
//             }
//         })
//         .catch(error => console.error('Error:', error));
//     });

    
//     // Gestion de la soumission du formulaire de modification de vin
//     // Gestion de la soumission du formulaire de modification de vin
//     const formVinModif = document.getElementById('formvinModif');
//     if (formVinModif) {
//         formVinModif.addEventListener('submit', function (e) {
//             e.preventDefault();

//             const formData = new FormData(this);
//             const idVinModif = formData.get('id_vin_modif');

//             fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//                 method: 'PUT',
//                 body: JSON.stringify(Object.fromEntries(formData.entries())),
//                 headers: {
//                     'Content-Type': 'application/json'
//                 }
//             })
//             .then(response => response.json())
//             .then(data => {
//                 console.log(data);
//                 updateDataInTableVin(data);
//                 showModal(data);
//             })
//             .catch(error => console.error('Error:', error));
//         });
//     }

//     // const formVinModif = document.getElementById('formvinModif');
//     // formVinModif.addEventListener('submit', function (e) {
//     //     e.preventDefault();

//     //     const formData = new FormData(this);
//     //     const idVinModif = formData.get('id_vin_modif');

//     //     fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//     //         method: 'PUT',
//     //         body: JSON.stringify(Object.fromEntries(formData.entries())),
//     //         headers: {
//     //             'Content-Type': 'application/json'
//     //         }
//     //     })
//     //     .then(response => response.json())
//     //     .then(data => {
//     //         console.log(data);
//     //         updateDataInTableVin(data);
//     //         showModal(data);
//     //     })
//     //     .catch(error => console.error('Error:', error));
//     // });

//     // Récupérer les données des vins et les afficher dans le tableau
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     // Effacer le contenu actuel du tableau
//     tableVin.innerHTML = '';

//     // Vérifier si data est un objet ou un tableau
//     if (typeof data === 'object' && !Array.isArray(data)) {
//         // Si data est un objet, ajouter chaque entrée dans le tableau
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const vin = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${vin.id_vin}</td>
//                     <td>${vin.vin_couleur}</td>
//                     <td>${vin.vin_region}</td>
//                     <td>${vin.vin_appellation}</td>
//                     <td>${vin.vin_terroir}</td>
//                     <td>${vin.vin_domaine}</td>
//                 `;
//                 tableVin.appendChild(newRow);
//             }
//         }
//     } else if (Array.isArray(data)) {
//         // Si data est un tableau, ajouter chaque élément dans le tableau
//         data.forEach(vin => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         });
//     } else {
//         console.error('Error: Data is not an object or array.');
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function updateCircleColor(id, socket) {
//     fetch(`http://localhost:3000/get/vin/${id}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data && data.status === 1 && data.vin && data.vin.id_vin) {
//                 const couleur = data.vin.vin_couleur;
//                 socket.emit('updateColor', { id: data.vin.id_vin, couleur: couleur });
//             } else {
//                 console.error('Erreur lors de la récupération des détails du vin:', data.status_message);
//             }
//         })
//         .catch(error => {
//             console.error('Erreur lors de la récupération des détails du vin:', error);
//         });
// }



// function updateCircleColor(id,socket) {
//     fetch(`http://localhost:3000/get/vin/${id}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.status === 1) {
//                 const couleur = data.vin.vin_couleur;
//                 socket.emit('updateColor', { id: id, couleur: couleur });
//             } else {
//                 console.error('Erreur lors de la récupération des détails du vin:', data.status_message);
//             }
//         })
//         .catch(error => {
//             console.error('Erreur lors de la récupération des détails du vin:', error);
//         });
// }




// document.addEventListener('DOMContentLoaded', function () {
//     const formVin = document.getElementById('formvin');
//     const formVinModif = document.getElementById('formvinModif'); // Ajout de la sélection du formulaire de modification

//     // Gestion de la soumission du formulaire d'ajout de vin
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault(); // Empêche le rechargement de la page

//         // Récupération des données du formulaire
//         const formData = new FormData(this);

//         // Envoi des données au serveur
//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             // Affichage des données reçues dans une modal
//             console.log(data);
//             showModal(data);
//             // Mise à jour de la couleur du cercle SVG
//             updateCircleColor(data); // Passer les données à la fonction
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Fonction pour mettre à jour la couleur du cercle SVG en fonction des données du formulaire
//     function updateCircleColor(bouteillesData) { // Ajout du paramètre bouteillesData
//         const selectedColor = bouteillesData.vin_couleur; // Utilisation des données du formulaire
//         const cercle = document.querySelector(`.wine-circle[data-id_bouteilles="${bouteillesData.id_vin}"]`);
//         if (cercle) {
//             cercle.style.fill = selectedColor;
//         } else {
//             console.error('Cercle non trouvé pour ce vin');
//         }
//     }

//    
//     // Gestion de la soumission du formulaire de modification de vin
//     formVinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         const idVinModif = formData.get('id_vin_modif');

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             updateDataInTableVin(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Récupérer les données des vins et les afficher dans le tableau
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     // Effacer le contenu actuel du tableau
//     tableVin.innerHTML = '';

//     // Vérifier si data est un objet ou un tableau
//     if (typeof data === 'object' && !Array.isArray(data)) {
//         // Si data est un objet, ajouter chaque entrée dans le tableau
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const vin = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${vin.id_vin}</td>
//                     <td>${vin.vin_couleur}</td>
//                     <td>${vin.vin_region}</td>
//                     <td>${vin.vin_appellation}</td>
//                     <td>${vin.vin_terroir}</td>
//                     <td>${vin.vin_domaine}</td>
//                 `;
//                 tableVin.appendChild(newRow);
//             }
//         }
//     } else if (Array.isArray(data)) {
//         // Si data est un tableau, ajouter chaque élément dans le tableau
//         data.forEach(vin => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         });
//     } else {
//         console.error('Error: Data is not an object or array.');
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }










// document.addEventListener('DOMContentLoaded', function () {
//     const formVin = document.getElementById('formvin');
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Gestion de l'affichage du formulaire d'ajout de vin
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden');
//     });

//     // Gestion de la soumission du formulaire d'ajout de vin
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault(); // Empêche le rechargement de la page

//         // Récupération des données du formulaire
//         const formData = new FormData(this);

//         // Envoi des données au serveur
//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             // Affichage des données reçues dans une modal
//             console.log(data);
//             showModal(data);
//             // Mise à jour de la couleur du cercle SVG
//             updateCircleColor();
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Fonction pour mettre à jour la couleur du cercle SVG en fonction de la sélection du formulaire
//     function updateCircleColor() {
//         const selectedColor = document.getElementById('vin_couleur').value;
//         const cercle = document.querySelector('.wine-circle');
//         if (cercle) {
//             cercle.style.fill = selectedColor;
//         } else {
//             console.error('Cercle introuvable');
//         }
//     }

//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     });

//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         const idVinModif = formData.get('id_vin_modif');

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             updateDataInTableVin(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });


// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     // Effacer le contenu actuel du tableau
//     tableVin.innerHTML = '';

//     // Vérifier si data est un objet ou un tableau
//     if (typeof data === 'object' && !Array.isArray(data)) {
//         // Si data est un objet, ajouter chaque entrée dans le tableau
//         for (const key in data) {
//             if (data.hasOwnProperty(key)) {
//                 const vin = data[key];
//                 const newRow = document.createElement('tr');
//                 newRow.innerHTML = `
//                     <td>${vin.id_vin}</td>
//                     <td>${vin.vin_couleur}</td>
//                     <td>${vin.vin_region}</td>
//                     <td>${vin.vin_appellation}</td>
//                     <td>${vin.vin_terroir}</td>
//                     <td>${vin.vin_domaine}</td>
//                 `;
//                 tableVin.appendChild(newRow);
//             }
//         }
//     } else if (Array.isArray(data)) {
//         // Si data est un tableau, ajouter chaque élément dans le tableau
//         data.forEach(vin => {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         });
//     } else {
//         console.error('Error: Data is not an object or array.');
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }


// });


// // Récupérer la couleur du vin
// const vinCouleur = bouteillesData.vin_couleur;

// // Appliquer la couleur au cercle
// const cercle = document.querySelector(`.wine-circle[data-id_bouteilles="${bouteillesData.id_vin}"]`);
// if (cercle) {
//     cercle.style.fill = vinCouleur;
// } else {
//     console.error('Cercle non trouvé pour ce vin');
// }

// // Mettre à jour la couleur des cercles au chargement de la page
// updateCircleColor();






// document.addEventListener('DOMContentLoaded', function () {
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden');
//     });

//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             row.style.display = rowContainsSearchTerm ? '' : 'none';
//         });
//     });

//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         const idVinModif = formData.get('id_vin_modif');

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             updateDataInTableVin(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     // Effacer le contenu actuel du tableau
//     tableVin.innerHTML = '';

//     // Itérer sur les données et ajouter chaque entrée dans le tableau
//     data.forEach(vin => {
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${vin.id_vin}</td>
//             <td>${vin.vin_couleur}</td>
//             <td>${vin.vin_region}</td>
//             <td>${vin.vin_appellation}</td>
//             <td>${vin.vin_terroir}</td>
//             <td>${vin.vin_domaine}</td>
//         `;
//         tableVin.appendChild(newRow);
//     });
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }


























// document.addEventListener('DOMContentLoaded', function () {
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden');
//     });

//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data);
//     })
//     .catch(error => console.error('Error:', error));

//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });

//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         const idVinModif = formData.get('id_vin_modif');

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, {
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             updateDataInTableVin(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent;

//         if (vinId === idVin) {
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }



















// document.addEventListener('DOMContentLoaded', function () {
//     // Récupérer les éléments HTML nécessaires
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Ajouter un écouteur d'événements pour le bouton "AJOUTER UN VIN"
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire d'ajout
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data); // Afficher les données dans le modal
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });
    
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data); // Ajouter les données au tableau
//     })
//     .catch(error => console.error('Error:', error));

//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire de modification
//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         const idVinModif = formData.get('id_vin_modif'); // Récupérer l'ID du vin à modifier

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, { // Construire l'URL avec l'ID du vin
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())), // Envoyer les nouvelles données du vin
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Mettre à jour le tableau affichant les vins avec les données modifiées
//             updateDataInTableVin(data);
//             showModal(data); // Afficher les données modifiées dans le modal
//         })
//         .catch(error => console.error('Error:', error));
//     });

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

//     // Itérer sur les propriétés de l'objet data et ajouter les données au tableau
//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent; // Récupérer l'ID du vin dans la première colonne

//         if (vinId === idVin) {
//             // Mettre à jour les données du vin dans le tableau
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block'; // Afficher le modal
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
// }


// document.addEventListener('DOMContentLoaded', function () {
//     // Récupérer les éléments HTML nécessaires
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Ajouter un écouteur d'événements pour le bouton "AJOUTER UN VIN"
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire d'ajout
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data); // Afficher les données dans le modal
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });
    
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data); // Ajouter les données au tableau
//     })
//     .catch(error => console.error('Error:', error));

//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire de modification
//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         const idVinModif = formData.get('id_vin_modif'); // Récupérer l'ID du vin à modifier

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, { // Construire l'URL avec l'ID du vin
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())), // Envoyer les nouvelles données du vin
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Mettre à jour le tableau affichant les vins avec les données modifiées
//             updateDataInTableVin(data);
//             showModal(data); // Afficher les données modifiées dans le modal
//         })
//         .catch(error => console.error('Error:', error));
//     });

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

//     // Itérer sur les propriétés de l'objet data et ajouter les données au tableau
//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent; // Récupérer l'ID du vin dans la première colonne

//         if (vinId === idVin) {
//             // Mettre à jour les données du vin dans le tableau
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block'; // Afficher le modal
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
// }







// document.addEventListener('DOMContentLoaded', function () {
//     // Récupérer les éléments HTML nécessaires
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Ajouter un écouteur d'événements pour le bouton "AJOUTER UN VIN"
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire d'ajout
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data); // Afficher les données dans le modal
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });
    
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data); // Ajouter les données au tableau
//     })
//     .catch(error => console.error('Error:', error));

//     // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             // Afficher ou masquer la ligne en fonction du terme de recherche
//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire de modification
//     formvinModif.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         const idVinModif = formData.get('id_vin_modif'); // Récupérer l'ID du vin à modifier

//         fetch(`http://localhost:3000/update/vin/${idVinModif}`, { // Construire l'URL avec l'ID du vin
//             method: 'PUT',
//             body: JSON.stringify(Object.fromEntries(formData.entries())), // Envoyer les nouvelles données du vin
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // Mettre à jour le tableau affichant les vins avec les données modifiées
//             updateDataInTableVin(data);
//             showModal(data); // Afficher les données modifiées dans le modal
//         })
//         .catch(error => console.error('Error:', error));
//     });

// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

//     // Itérer sur les propriétés de l'objet data et ajouter les données au tableau
//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }

// function updateDataInTableVin(data) {
//     const idVin = data.id_vin;
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         const vinId = cells[0].textContent; // Récupérer l'ID du vin dans la première colonne

//         if (vinId === idVin) {
//             // Mettre à jour les données du vin dans le tableau
//             cells[1].textContent = data.vin_couleur;
//             cells[2].textContent = data.vin_region;
//             cells[3].textContent = data.vin_appellation;
//             cells[4].textContent = data.vin_terroir;
//             cells[5].textContent = data.vin_domaine;
//         }
//     });
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block'; // Afficher le modal
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none'; // Masquer le modal
// }




// document.addEventListener('DOMContentLoaded', function () {
//     // Récupérer les éléments HTML nécessaires
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const formVin = document.getElementById('formvin');
//     const formvinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Ajouter un écouteur d'événements pour le bouton "AJOUTER UN VIN"
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     // Ajouter un écouteur d'événements pour soumettre le formulaire
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Récupérer les données du formulaire

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data); // Afficher les données dans le modal
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });
    
//     fetch('http://localhost:3000/get/vin')
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         addDataToTableVin(data); // Ajouter les données au tableau
//     })
//     .catch(error => console.error('Error:', error));

// // Ajouter un écouteur d'événements pour la barre de recherche
//     searchInputVin.addEventListener('input', function () {
//     const searchTerm = searchInputVin.value.toLowerCase();
//     const rows = document.querySelectorAll('#tableVinBody tr');

//     // Parcourir chaque ligne du tableau et cacher celles qui ne correspondent pas à la recherche
//     rows.forEach(row => {
//         const cells = row.querySelectorAll('td');
//         let rowContainsSearchTerm = false;

//         cells.forEach(cell => {
//             if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                 rowContainsSearchTerm = true;
//             }
//         });

//         // Afficher ou masquer la ligne en fonction du terme de recherche
//         if (rowContainsSearchTerm) {
//             row.style.display = '';
//         } else {
//             row.style.display = 'none';
//         }
//     });
// });
// }); 

// function addDataToTableVin(data) {
// const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

// // Itérer sur les propriétés de l'objet data et ajouter les données au tableau
// for (const key in data) {
//     if (data.hasOwnProperty(key)) {
//         const vin = data[key];
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${vin.id_vin}</td>
//             <td>${vin.vin_couleur}</td>
//             <td>${vin.vin_region}</td>
//             <td>${vin.vin_appellation}</td>
//             <td>${vin.vin_terroir}</td>
//             <td>${vin.vin_domaine}</td>
//         `;
//         tableVin.appendChild(newRow);
//     }
// }
// }

// function showModal(data) {
// const modalDataDisplay = document.getElementById('modalDataDisplay');
// modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

// const modal = document.getElementById('myModal');
// modal.style.display = 'block'; // Afficher le modal
// }

// function closeModal() {
// const modal = document.getElementById('myModal');
// modal.style.display = 'none'; // Masquer le modal
// }









// document.addEventListener('DOMContentLoaded', function () {

//     const addWineButton = document.getElementById('addWineButton');
//     const formVin = document.getElementById('formvin');
//     const searchInputVin = document.getElementById('searchInputVin');

//     addWineButton.addEventListener('click', function () {
//         formVin.classList.toggle('hidden');
//     });

//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/vin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/vin')
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableVin(data);
//         })
//         .catch(error => console.error('Error:', error));

//     searchInputVin.addEventListener('input', function () {
//         const searchTerm = searchInputVin.value.toLowerCase();
//         const rows = document.querySelectorAll('#tableVinBody tr');

//         rows.forEach(row => {
//             const cells = row.querySelectorAll('td');
//             let rowContainsSearchTerm = false;

//             cells.forEach(cell => {
//                 if (cell.textContent.toLowerCase().includes(searchTerm)) {
//                     rowContainsSearchTerm = true;
//                 }
//             });

//             if (rowContainsSearchTerm) {
//                 row.style.display = '';
//             } else {
//                 row.style.display = 'none';
//             }
//         });
//     });
// });

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody');

//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <!-- Ajoutez d'autres colonnes ici selon vos besoins -->
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }

// document.addEventListener('DOMContentLoaded', function () {
//     const ajouterInfoTab = document.getElementById('ajouterInfoTab');
//     const modifButton = document.getElementById('modifButton');
//     const formVin = document.getElementById('formvin');
//     const formVinModif = document.getElementById('formvinModif');
//     const searchInputVin = document.getElementById('searchInputVin');

//     // Écouteur d'événements pour afficher/masquer le formulaire d'ajout
//     ajouterInfoTab.addEventListener('click', function () {
//         formVin.classList.toggle('hidden');
//     });

//     // Écouteur d'événements pour afficher/masquer le formulaire de modification
//     modifButton.addEventListener('click', function () {
//         formVinModif.classList.toggle('hidden');
//     });

//     // Ajoutez d'autres écouteurs d'événements au besoin

//     // Fonction pour ajouter des données au tableau de vins
//     function addDataToTableVin(data) {
//         const tableVinBody = document.getElementById('tableVinBody');
//         tableVinBody.innerHTML = ''; // Efface le contenu précédent du tableau

//         // Itérer sur les données et les ajouter au tableau
//         data.forEach(function (vin) {
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVinBody.appendChild(newRow);
//         });
//     }

//     // Fonction pour afficher les données dans le modal
//     function showModal(data) {
//         const modalDataDisplay = document.getElementById('modalDataDisplay');
//         modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//         const modal = document.getElementById('myModal');
//         modal.style.display = 'block'; // Afficher le modal
//     }

//     // Fonction pour fermer le modal
//     function closeModal() {
//         const modal = document.getElementById('myModal');
//         modal.style.display = 'none'; // Masquer le modal
//     }

//     // Écouteur d'événements pour soumettre le formulaire d'ajout
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);
//         const jsonData = JSON.stringify(Object.fromEntries(formData.entries()));

//         fetch('https://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: jsonData,
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data); // Afficher les données dans le modal
//             addDataToTableVin(data); // Ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     // Ajoutez d'autres écouteurs d'événements au besoin

// });



















    //  // Ajouter un écouteur d'événements pour soumettre le formulaire
    //  formvinModif.addEventListener('submit', function (e) {
    //     e.preventDefault();

    //     const formData = new FormData(this); // Récupérer les données du formulaire

    //     fetch('http://localhost:3000/update/vin/:ID', {
    //         method: 'UPDATE',
    //         body: JSON.stringify(Object.fromEntries(formData.entries())),
    //         headers: {
    //             'Content-Type': 'application/json'
    //         }
    //     })
    //     .then(response => response.json())
    //     .then(data => {
    //         console.log(data);
    //         showModal(data); // Afficher les données dans le modal
    //         addDataToTableVin(data); // Ajouter les données du formulaire au tableau
    //     })
    //     .catch(error => console.error('Error:', error));
    // });

    // Récupérer les données des vins depuis l'API
   
// document.addEventListener('DOMContentLoaded', function () {

//     const addWineButton = document.getElementById('addWineButton');
//     const formVin = document.getElementById('formvin');

//     fetch('http://localhost:3000/get/vin') // Modifier l'URL en fonction de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableVin(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));

//         addWineButton.addEventListener('click', function () {
//             formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//         }); 
        
//     fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//             'Content-Type': 'application/json'
//                     }
//              })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//         }); 




// document.addEventListener('DOMContentLoaded', function () {

//     const addWineButton = document.getElementById('addWineButton');
//     const formVin = document.getElementById('formvin');

//     addWineButton.addEventListener('click', function () {
//         formVin.classList.toggle('hidden'); // Afficher ou masquer le formulaire
//     });

//     // Ajoutez un écouteur d'événements pour soumettre le formulaire
//     formVin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this); // Définissez formData ici

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     fetch('http://localhost:3000/get/vin') // Modifier l'URL en fonction de votre API
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             addDataToTableVin(data); // Appeler la fonction pour ajouter les données au tableau
//         })
//         .catch(error => console.error('Error:', error));
// }); 

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

//     // Itérer sur les propriétés de l'objet data
//     for (const key in data) {
//         if (data.hasOwnProperty(key)) {
//             const vin = data[key];
//             const newRow = document.createElement('tr');
//             newRow.innerHTML = `
//                 <td>${vin.id_vin}</td>
//                 <td>${vin.vin_couleur}</td>
//                 <td>${vin.vin_region}</td>
//                 <td>${vin.vin_appellation}</td>
//                 <td>${vin.vin_terroir}</td>
//                 <td>${vin.vin_domaine}</td>
//             `;
//             tableVin.appendChild(newRow);
//         }
//     }
// }


// // function addDataToTableVin(data) {
// //     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

// //     // Boucler à travers les données et les ajouter au tableau
// //     data.forEach(vin => {
// //         const newRow = document.createElement('tr');
// //         newRow.innerHTML = `
// //             <td>${vin.id_vin}</td>
// //             <td>${vin.vin_couleur}</td>
// //             <td>${vin.vin_region}</td>
// //             <td>${vin.vin_appellation}</td>
// //             <td>${vin.vin_terroir}</td>
// //             <td>${vin.vin_domaine}</td>
// //         `;
// //         tableVin.appendChild(newRow);
// //     });
// // }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }





























   
        

// function addDataToTableVin(data) {
//     const tableVin = document.getElementById('tableVinBody'); // Récupérer l'élément tbody du tableau

//     // Boucler à travers les données et les ajouter au tableau
//     data.forEach(vin => {
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${vin.id_vin}</td>
//             <td>${vin.vin_couleur}</td>
//             <td>${vin.vin_region}</td>
//             <td>${vin.vin_appellation}</td>
//             <td>${vin.vin_terroir}</td>
//             <td>${vin.vin_domaine}</td>
//         `;
//         tableVin.appendChild(newRow);
//     });

    
// }

// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }










// document.addEventListener('DOMContentLoaded', function () {
//     const formvin = document.getElementById('formvin'); // Déclarer la variable formVin ici

//     formvin.addEventListener('submit', function (e) {
//         e.preventDefault();

//         const formData = new FormData(this);

//         fetch('http://localhost:3000/post/bouteillesvin', {
//             method: 'POST',
//             body: JSON.stringify(Object.fromEntries(formData.entries())),
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//             addDataToTableVin(data); // Ajouter les données du formulaire au tableau
//         })
//         .catch(error => console.error('Error:', error));
//     });

//     function addDataToTableVin(data) {
//         console.log(data);
//         const formDataDisplay = document.getElementById('TabVin').getElementsByTagName('tbody')[0]; // Récupérer l'élément tbody
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${data.data.id_vin}</td>
//             <td>${data.data.vin_couleur}</td>
//             <td>${data.data.vin_region}</td>
//             <td>${data.data.vin_appellation}</td>
//             <td>${data.data.vin_terroir}</td>
//             <td>${data.data.vin_domaine}</td>
//         `;
//         formDataDisplay.appendChild(newRow);
//     }
    
    

//     // Reste de votre code...
// });








































// // document.addEventListener('DOMContentLoaded', function () {
// //     // const formBouteilles = document.getElementById('myForm');
// //     const formVin = document.getElementById('Formvin');

// //     // formBouteilles.addEventListener('submit', function (e) {
// //     //     e.preventDefault();

// //     //     const formData = new FormData(this);

// //     //     fetch('http://localhost:3000/post/bouteilles', {
// //     //         method: 'POST',
// //     //         body: JSON.stringify(Object.fromEntries(formData.entries())),
// //     //         headers: {
// //     //             'Content-Type': 'application/json'
// //     //         }
// //     //     })
// //     //     .then(response => response.json())
// //     //     .then(data => {
// //     //         console.log(data);
// //     //         showModal(data);
// //     //     })
// //     //     .catch(error => console.error('Error:', error));
// //     // });

// //     formVin.addEventListener('submit', function (e) {
// //         e.preventDefault();

// //         const formData = new FormData(this);

// //         fetch('http://localhost:3000/post/bouteillesvin', {
// //             method: 'POST',
// //             body: JSON.stringify(Object.fromEntries(formData.entries())),
// //             headers: {
// //                 'Content-Type': 'application/json'
// //             }
// //         })
// //         .then(response => response.json())
// //         .then(data => {
// //             console.log(data);
// //             showModal(data);
// //         })
// //         .catch(error => console.error('Error:', error));
// //     });




// formVin.addEventListener('submit', function (e) {
//     e.preventDefault();

//     const formData = new FormData(this);
//     const formVin = document.getElementById('Formvin');


//     fetch('http://localhost:3000/post/bouteillesvin', {
//         method: 'POST',
//         body: JSON.stringify(Object.fromEntries(formData.entries())),
//         headers: {
//             'Content-Type': 'application/json'
//         }
//     })
//     .then(response => response.json())
//     .then(data => {
//         console.log(data);
//         showModal(data);

//         // Ajouter les données du formulaire au tableau
//         addDataToTable(formData); // Utilisez formData au lieu de TabVin
//     })
//     .catch(error => console.error('Error:', error));
// });


//     function addDataToTable(data) {
//         const newRow = document.createElement('tr');
//         newRow.innerHTML = `
//             <td>${data.id_vin}</td>
//             <td>${data.vin_couleur}</td>
//             <td>${data.vin_region}</td>
//             <td>${data.vin_appellation}</td>
//             <td>${data.vin_terroir}</td>
//             <td>${data.vin_domaine}</td>
//         `;
//         formDataDisplay.appendChild(newRow);
//     }

//     // Reste de votre code...
//     document.getElementById('deleteButton').addEventListener('click', function () {
//         const deleteId = document.getElementById('deleteId').value;

//         fetch(`http://localhost:3000/delete/bouteilles/${deleteId}`, {
//             method: 'DELETE',
//             headers: {
//                 'Content-Type': 'application/json'
//             }
//         })
//         .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             showModal(data);
//         })
//         .catch(error => console.error('Error:', error));
//     });


// function showModal(data) {
//     const modalDataDisplay = document.getElementById('modalDataDisplay');
//     modalDataDisplay.innerHTML = `<p>${JSON.stringify(data)}</p>`;

//     const modal = document.getElementById('myModal');
//     modal.style.display = 'block';
// }

// function closeModal() {
//     const modal = document.getElementById('myModal');
//     modal.style.display = 'none';
// }


