const socket = io();

socket.on('data', (data) => {
    console.log(data);
    // Sélectionner le corps du tableau
    const tableBody = document.querySelector('#mesures-table tbody');

    // Créer une nouvelle ligne pour les nouvelles données
    const newRow = document.createElement('tr');

    // Remplir la nouvelle ligne avec les données reçues
    newRow.innerHTML = `
        <td>${data.Humidite}</td>
        <td>${data.Temperature}</td>
        <td>${data.Time}</td>
    `;
    
    // Ajouter la nouvelle ligne au corps du tableau
    tableBody.appendChild(newRow);
});






// const socket = io('http://localhost:3000');



// socket.on('data', (data) => {
//     const { Temperature, Humidite, Time } = data;
//     const mesurestable = document.getElementById('mesures-table');
//     mesurestable.innerHTML += `<tr><td>${Temperature}</td><td>${Humidite}</td><td>${Time}</td></tr>`;
// });

// function construireTableau(data) {
//     const tbody = document.querySelector('#mesures-table tbody');
//     tbody.innerHTML = '';
//     data.forEach(mesurestable => {
//         const row = document.createElement('tr');
//         const temperatureCell = document.createElement('td');
//         const humiditeCell = document.createElement('td');
//         const TimeCell = document.createElement('td');

//         temperatureCell.textContent = mesurestable.Temperature;
//         humiditeCell.textContent = mesurestable.Humidite;
//         TimeCell.textContent = mesurestable.Time;

//         row.appendChild(temperatureCell);
//         row.appendChild(humiditeCell);
//         row.appendChild(TimeCell);

//         tbody.appendChild(row);
//     });
// }
