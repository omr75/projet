const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const mqtt = require('mqtt');
const app = express();
const http = require('http');
const serveur = http.createServer(app);
const io = require('socket.io')(serveur);
const path = require('path');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'PUBLIC')));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'Cave',
    port: 8889,
});

db.connect();

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'PUBLIC','accueil.html'));
   
});

const server = 'mqtts://63.34.215.128:8883'; 
const options = {
    clientId: 'sofiane',
    username: 'sosohygrometrie',
    password: 'NNSXS.TK2JKGDVTUCTLPOHR7ETPZDSNSDFOTFIYAGGJJY.ZU4WVFG6K6MHKBVK3CYFAFPSDUSLXYHGIVNXKWWESJRHLHVGSDBA', 
    rejectUnauthorized: false 
};

const client = mqtt.connect(server, options);

client.on('connect', () => {
    console.log('Connecté au courtier MQTTS');
    client.subscribe('v3/sosohygrometrie@ttn/devices/eui-a8610a35301e8909/up', { qos: 0 });
});

client.on('message', (topic, message) => {
    const data = JSON.parse(message.toString());

    const Temperature = data.uplink_message.decoded_payload.temperature;
    const Humidite = data.uplink_message.decoded_payload.humidity;

    console.log('Température:', Temperature);
    console.log('Humidité:', Humidite);

    const query = 'INSERT INTO Mesures (Temperature, Humidite, Time) VALUES (?, ?, ?)';
    db.query(query, [Temperature, Humidite, new Date()], (err, result) => {
        if (err) {
            console.error(err);
            return;
        }
        console.log('Data inserted into database:', result);
    });

    io.emit('Temperature', Temperature);
    io.emit('Humidite', Humidite);
});

client.on('error', (err) => {
    console.error('Erreur de connexion:', err);
    client.end();
});

io.on('connection', (socket) => {
    console.log('Client connected');
});


app.get('/get/vin', (req, res) => {
    let sql = 'SELECT * FROM VIN';
    db.query(sql, (err, results) => {
        if (err) throw err;
        res.send(results);
    });
});

app.get('/get/vin/:id_vin', (req, res) => {
    const sql = 'SELECT * FROM VIN WHERE id_vin = ?';
    db.query(sql, [req.params.id_vin], (err, result) => {
        if (err) {
            console.error(err);
            res.send({ status: 0, status_message: 'Error retrieving VIN data.' });
            return;
        }

        if (result.length > 0) {
            res.send({ status: 1, status_message: 'VIN data retrieved with success.', vin: result[0] });
        } else {
            res.send({ status: 0, status_message: 'VIN not found.' });
        }
    });
});



app.get('/get/bouteilles/:ID', (req, res) => {
    const sql = 'SELECT * FROM BOUTEILLES WHERE id_bouteilles = ?';
    db.query(sql, [req.params.ID], (err, result) => {
        if (err) {
            console.error(err);
            res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
            return;
        }

        if (result.length > 0) {
            res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
        } else {
            res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
        }
    });
});

app.get('/get/bouteilles', (req, res) => {
    let sql = 'SELECT b.*, v.*, v.vin_couleur AS couleur_vin FROM BOUTEILLES b JOIN VIN v ON b.id_vin = v.id_vin';
    db.query(sql, (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error' });
            return;
        }
        res.send(results);
    });
});

app.post('/post/bouteilles', (req, res) => {
    const {
        id_bouteilles,
        bouteilles_duree,
        bouteilles_millesime,
        bouteilles_cote,
        bouteilles_prix,
        bouteilles_date_conso,
        bouteilles_remarques,
        id_vin,
    } = req.body;


    
        const queryInsert = 'INSERT IGNORE INTO `BOUTEILLES` (`id_bouteilles`, `bouteilles_duree`, `bouteilles_millesime`, `bouteilles_cote`, `bouteilles_prix`, `bouteilles_date_conso`, `bouteilles_remarques`, `id_vin`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';

        db.query(queryInsert, [id_bouteilles, bouteilles_duree, bouteilles_millesime, bouteilles_cote, bouteilles_prix, bouteilles_date_conso, bouteilles_remarques, id_vin], (err, result) => {
            if (err) {
                console.error(err);
                res.status(500).send({ message: 'Internal Server Error' });
                return;
            }

            const insertedData = { id_bouteilles, bouteilles_duree, bouteilles_millesime, bouteilles_cote, bouteilles_prix, bouteilles_date_conso, bouteilles_remarques, id_vin };
            res.send({ message: 'BOUTEILLES successfully inserted !', data: insertedData });
            console.log(insertedData)
            console.log(result);
        });
    });
   

// Route pour insérer les données d'un vin
app.post('/post/bouteillesvin', (req, res) => {
    const {
        id_vin,
        vin_couleur,
        vin_region,
        vin_appellation,
        vin_terroir,
        vin_domaine,
    } = req.body;

    // Requête SQL pour l'insertion de données dans la table VIN
    const query = 'INSERT IGNORE INTO `VIN` (`id_vin`, `vin_couleur`, `vin_region`, `vin_appellation`, `vin_terroir`, `vin_domaine`) VALUES (?, ?, ?, ?, ?, ?)';
    
    db.query(query, [id_vin, vin_couleur, vin_region, vin_appellation, vin_terroir, vin_domaine], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send({ message: 'Internal Server Error' });
            return;
        }

        // Obtenez l'ID du vin inséré
        const insertedId = result.insertId;

        // Construisez l'objet de données à renvoyer dans la réponse
        const insertedVin = {
            id_vin: insertedId,
            vin_couleur,
            vin_region,
            vin_appellation,
            vin_terroir,
            vin_domaine,
        };

        // Envoyez la réponse avec l'ID du vin inséré
        res.send({ message: 'VIN successfully inserted !', data: insertedVin });

        // Envoyez la nouvelle couleur aux clients connectés via Socket.IO
        io.emit('colorUpdated', { id_vin: insertedId, vin_couleur: vin_couleur.toLowerCase(), vin_region, vin_appellation, vin_terroir, vin_domaine });

        console.log("Couleur envoyée aux clients :", vin_couleur);
    });
});

app.put('/update/bouteilles/:id_bouteilles', cors(), (req, res) => {
    const { id_bouteilles } = req.params;
    const { 
        id_bouteilles_modif, 
        bouteilles_duree_modif, 
        bouteilles_millesime_modif, 
        bouteilles_cote_modif, 
        bouteilles_prix_modif, 
        bouteilles_date_conso_modif, 
        bouteilles_remarques_modif,
        id_vin_modif 
    } = req.body;

    console.log('ID de la bouteille à mettre à jour :', id_bouteilles);
    console.log('Nouvelles valeurs :', req.body);

    const sql = `
        UPDATE bouteilles
        SET 
            id_bouteilles = ?,
            bouteilles_duree = ?,
            bouteilles_millesime = ?,
            bouteilles_cote = ?,
            bouteilles_prix = ?,
            bouteilles_date_conso = ?,
            bouteilles_remarques = ?,
            id_vin = ?
        WHERE id_bouteilles = ?`;

    db.query(sql, [id_bouteilles_modif, bouteilles_duree_modif, bouteilles_millesime_modif, bouteilles_cote_modif, bouteilles_prix_modif, bouteilles_date_conso_modif, bouteilles_remarques_modif, id_vin_modif, id_bouteilles], (err, result) => {
        if (err) {
            console.error('Erreur lors de la mise à jour de la bouteille :', err);
            res.status(500).send({ message: 'Internal Server Error' });
            return;
        }
        console.log('Résultat de la mise à jour :', result);
        res.send({ status: 1, status_message: 'Bouteille mise à jour avec succès.', data: result });
    });
});

app.put('/update/vin/:id_vin', (req, res) => {
    const { vin_couleur_modif, vin_region_modif, vin_appellation_modif, vin_terroir_modif, vin_domaine_modif } = req.body;
    const { id_vin } = req.params;

    console.log('ID du vin à mettre à jour :', id_vin);
    console.log('Nouvelles valeurs :', req.body);

    const sql = `
        UPDATE VIN 
        SET 
            vin_couleur = ?,
            vin_region = ?,
            vin_appellation = ?,
            vin_terroir = ?,
            vin_domaine = ?
        WHERE id_vin = ?`;

    db.query(sql, [vin_couleur_modif, vin_region_modif, vin_appellation_modif, vin_terroir_modif, vin_domaine_modif, id_vin], (err, result) => {
        if (err) {
            console.error('Erreur lors de la mise à jour du VIN :', err);
            res.status(500).send({ message: 'Internal Server Error' });
            return;
        }
        console.log('Résultat de la mise à jour :', result);

        res.send({ status: 1, status_message: 'VIN updated with success.', data: result });
    });
});

app.delete('/delete/bouteilles/:ID', (req, res) => {
const sql = `DELETE FROM BOUTEILLES WHERE id_bouteilles=${req.params.ID}`;
db.query(sql, (err, result) => {
    if (err) {
        console.error(err);
        res.send({ status: 0, status_message: 'Error deleting BOUTEILLES.' });
        return;
    }
    console.log(result);
    res.send({ status: 1, status_message: 'BOUTEILLES deleted with success.' });
});
});

serveur.listen(3000, () => {
console.log('Server started on port 3000');
});
// app.get('/get/bouteilles', (req, res) => {
//     let sql = 'SELECT b.*, v.* FROM BOUTEILLES b JOIN VIN v ON b.id_vin = v.id_vin';
//     db.query(sql, (err, results) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send({ message: 'Internal Server Error' });
//             return;
//         }
//         res.send(results);
//     });
// });


// app.get('/get/bouteilles', (req, res) => {
//     let sql = 'SELECT * FROM BOUTEILLES';
//     db.query(sql, (err, results) => {
//         if (err) throw err;
//         res.send(results);
//     });
// });

// Route pour récupérer les dernières bouteilles ajoutées
// app.get('/get/latest_bouteilles', (req, res) => {
//     const sql = 'SELECT * FROM BOUTEILLES ORDER BY id_bouteilles DESC LIMIT 5'; // Récupère les 5 dernières bouteilles ajoutées
//     db.query(sql, (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send({ message: 'Internal Server Error' });
//             return;
//         }

//         res.send(result);
//     });
// });

// // Route pour récupérer les dernières bouteilles supprimées
// app.get('/get/latest_deleted_bouteilles', (req, res) => {
//     const sql = 'SELECT * FROM BOUTEILLES ORDER BY id_bouteilles DESC LIMIT 5'; // Récupère les 5 dernières bouteilles supprimées
//     db.query(sql, (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send({ message: 'Internal Server Error' });
//             return;
//         }

//         res.send(result);
//     });
// });




// // Route pour insérer les données d'un vin
// app.post('/post/bouteillesvin', (req, res) => {
//     const {
//         id_vin,
//         vin_region,
//         vin_appellation,
//         vin_terroir,
//         vin_domaine,
//         vin_couleur,
//     } = req.body;

    

//     // Requête SQL pour l'insertion de données dans la table VIN
//     const query = 'INSERT IGNORE INTO `VIN` (`id_vin`,`vin_couleur`, `vin_region`, `vin_appellation`, `vin_terroir`, `vin_domaine`) VALUES (?,?, ?, ?, ?, ?)';
    
//     db.query(query, [id_vin, vin_couleur, vin_region, vin_appellation, vin_terroir, vin_domaine], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send({ message: 'Internal Server Error' });
//             return;
//         }

//         // Obtenez l'ID du vin inséré
//         const insertedId = result.insertId;

//         // Construisez l'objet de données à renvoyer dans la réponse
//         const insertedVin = {
//             id_vin: insertedId,
//             vin_couleur,
//             vin_region,
//             vin_appellation,
//             vin_terroir,
//             vin_domaine,
//         };

//         // Envoyez la réponse avec l'ID du vin inséré
//         res.send({ message: 'VIN successfully inserted !', data: insertedVin });
//         // Envoyez la nouvelle couleur aux clients connectés via Socket.IO
//         // Envoyez la nouvelle couleur aux clients connectés via Socket.IO
//         // io.emit('colorUpdated', { id_vin: insertedId, vin_couleur: vin_couleur.toLowerCase() });
//         io.emit('colorUpdated', { id_vin: insertedId, vin_couleur: vin_couleur.toLowerCase(), vin_region, vin_appellation, vin_terroir, vin_domaine });

//         // Après avoir émis la couleur
//         console.log("Couleur envoyée aux clients :", vin_couleur);


//     });
// });


    // app.post('/reserve/bouteille/:id_bouteilles', (req, res) => {
    //     const { id_bouteilles } = req.params;
    
    //     // Vérifier si la bouteille existe dans la base de données
    //     const checkQuery = 'SELECT * FROM BOUTEILLES WHERE id_bouteilles = ?';
    //     db.query(checkQuery, [id_bouteilles], (err, result) => {
    //         if (err) {
    //             console.error(err);
    //             res.status(500).send({ message: 'Internal Server Error' });
    //             return;
    //         }
    
    //         // Si la bouteille n'existe pas
    //         if (result.length === 0) {
    //             res.status(404).send({ message: 'Bouteille not found' });
    //             return;
    //         }
    
    //         // Si la bouteille existe mais est déjà réservée
    //         if (result[0].is_reserved) {
    //             res.status(400).send({ message: 'Bouteille already reserved' });
    //             return;
    //         }
    
    //         // Mettre à jour la base de données pour marquer la bouteille comme réservée
    //         const updateQuery = 'UPDATE BOUTEILLES SET is_reserved = true WHERE id_bouteilles = ?';
    //         db.query(updateQuery, [id_bouteilles], (err, result) => {
    //             if (err) {
    //                 console.error(err);
    //                 res.status(500).send({ message: 'Internal Server Error' });
    //                 return;
    //             }
                
    //             res.status(200).send({ message: 'Bouteille reserved successfully' });
    //         });
    //     });
    // });

    // app.post('/reserve/vin/:id_vin', (req, res) => {
    //     const { id_vin } = req.params;
    
    //     // Vérifier si le vin existe dans la base de données
    //     const checkQuery = 'SELECT * FROM VIN WHERE id_vin = ?';
    //     db.query(checkQuery, [id_vin], (err, result) => {
    //         if (err) {
    //             console.error(err);
    //             res.status(500).send({ message: 'Internal Server Error' });
    //             return;
    //         }
    
    //         // Si le vin n'existe pas
    //         if (result.length === 0) {
    //             res.status(404).send({ message: 'Vin not found' });
    //             return;
    //         }
    
    //         // Si le vin existe mais est déjà réservé
    //         if (result[0].is_reserved) {
    //             res.status(400).send({ message: 'Vin already reserved' });
    //             return;
    //         }
    
    //         // Mettre à jour la base de données pour marquer le vin comme réservé
    //         const updateQuery = 'UPDATE VIN SET is_reserved = true WHERE id_vin = ?';
    //         db.query(updateQuery, [id_vin], (err, result) => {
    //             if (err) {
    //                 console.error(err);
    //                 res.status(500).send({ message: 'Internal Server Error' });
    //                 return;
    //             }
                
    //             res.status(200).send({ message: 'Vin reserved successfully' });
    //         });
    //     });
    // });
    
    
  
// app.put('/update/bouteilles/:id', (req, res) => {
//         const {
//             id_bouteilles,
//             bouteilles_duree,
//             bouteilles_millesime,
//             bouteilles_cote,
//             bouteilles_prix,
//             bouteilles_date_conso,
//             bouteilles_remarques,
//             id_vin
//         } = req.body;
    
//         // Vérifiez si id_vin est défini et est un nombre
//         if (typeof id_vin !== 'undefined' && !isNaN(id_vin)) {
//             const sql = `
//                 UPDATE BOUTEILLES 
//                 SET 
//                     id_bouteilles = ${id_bouteilles},
//                     bouteilles_duree = ${bouteilles_duree},
//                     bouteilles_millesime = ${bouteilles_millesime},
//                     bouteilles_cote = ${bouteilles_cote},
//                     bouteilles_prix = ${bouteilles_prix},
//                     bouteilles_date_conso = '${bouteilles_date_conso}',
//                     bouteilles_remarques = '${bouteilles_remarques}',
//                     id_vin = ${id_vin} 
//                 WHERE id_bouteilles = ${req.params.id}`;
    
//             db.query(sql, (err, result) => {
//                 if (err) {
//                     console.error(err);
//                     res.status(500).send({ message: 'Internal Server Error' });
//                     return;
//                 }
//                 // Le code pour gérer le succès de la requête ici
//                 res.send({ message: 'Bouteille mise à jour avec succès' });
//             });
//         } else {
//             res.status(400).send({ message: 'ID du vin invalide' });
//         }
//     });




    

    // app.put('/update/vin/:id_bouteilles', (req, res) => {
    //     const { id_bouteilles_modif, bouteilles_duree_modif, bouteilles_millesime_modif, bouteilles_cote_modif, bouteilles_prix_modif, bouteilles_date_conso_modif, bouteilles_remarques_modif, id_vin_modif } = req.body;
    //     const { id_bouteilles } = req.params;
    
    //     console.log('ID de la bouteille à mettre à jour :', id_bouteilles);
    //     console.log('Nouvelles valeurs :', req.body);
    
    //     const sql = `
    //         UPDATE bouteilles
    //         SET 
    //             id_bouteilles = ?,
    //             bouteilles_duree = ?,
    //             bouteilles_millesime = ?,
    //             bouteilles_cote = ?,
    //             bouteilles_prix = ?,
    //             bouteilles_date_conso = ?,
    //             bouteilles_remarques = ?
    //         WHERE id_bouteilles = ?`;
    
    //     db.query(sql, [id_bouteilles_modif, bouteilles_duree_modif, bouteilles_millesime_modif, bouteilles_cote_modif, bouteilles_prix_modif, bouteilles_date_conso_modif, bouteilles_remarques_modif, id_bouteilles], (err, result) => {
    //         if (err) {
    //             console.error('Erreur lors de la mise à jour de la bouteille :', err);
    //             res.status(500).send({ message: 'Internal Server Error' });
    //             return;
    //         }
    //         console.log('Résultat de la mise à jour :', result);
    //         res.send({ status: 1, status_message: 'Bouteille mise à jour avec succès.', data: result });
    //     });
    // });
    
    // app.put('/update/bouteilles', (req, res) => {
    //     const {
    //         id_bouteilles,
    //         bouteilles_duree,
    //         bouteilles_millesime,
    //         bouteilles_cote,
    //         bouteilles_prix,
    //         bouteilles_date_conso,
    //         bouteilles_remarques,
    //         id_vin
    //     } = req.body;
    
    //     // Vérifiez si id_vin est défini et est un nombre
    //     if (typeof id_vin !== 'undefined' && !isNaN(id_vin)) {
    //         const sql = `
    //             UPDATE BOUTEILLES 
    //             SET 
    //                 id_bouteilles = ${id_bouteilles},
    //                 bouteilles_duree = ${bouteilles_duree},
    //                 bouteilles_millesime = ${bouteilles_millesime},
    //                 bouteilles_cote = ${bouteilles_cote},
    //                 bouteilles_prix = ${bouteilles_prix},
    //                 bouteilles_date_conso = '${bouteilles_date_conso}',
    //                 bouteilles_remarques = '${bouteilles_remarques}',
    //                 id_vin = ${id_vin} 
    //             WHERE id_bouteilles = ${req.params.ID}`;
    
    //         db.query(sql, (err, result) => {
    //             if (err) {
    //                 console.error(err);
    //                 res.status(500).send({ message: 'Internal Server Error' });
    //                 return;
    //             }
    //             res.send({ status: 1, status_message: 'Bouteille updated with success.', data: result });
    //         });
    //     } else {
    //         res.status(400).send({ message: 'Invalid id_vin value' });
    //     }
    // });
   

    // app.put('/update/vin/:id_vin', (req, res) => {
    //     const { vin_couleur, vin_region, vin_appellation, vin_terroir, vin_domaine } = req.body;
    //     const { id_vin } = req.params;
    
    //     const sql = `
    //         UPDATE VIN 
    //         SET 
    //             vin_couleur = ?,
    //             vin_region = ?,
    //             vin_appellation = ?,
    //             vin_terroir = ?,
    //             vin_domaine = ?
    //         WHERE id_vin = ?`;
    
    //     db.query(sql, [vin_couleur, vin_region, vin_appellation, vin_terroir, vin_domaine, id_vin], (err, result) => {
    //         if (err) {
    //             console.error(err);
    //             res.status(500).send({ message: 'Internal Server Error' });
    //             return;
    //         }
    //         res.send({ status: 1, status_message: 'VIN updated with success.', data: result });
    //     });
    // });
    
    


// app.put('/update/vin/:ID', (req, res) => {
//         const {
//             id_vin,
//             vin_couleur,
//             vin_region,
//             vin_appellation,
//             vin_terroir,
//             vin_domaine,
            
//         } = req.body;
    
//         // Vérifiez si id_vin est défini et est un nombre
//         if (typeof id_vin !== 'undefined' && !isNaN(id_vin)) {
//             const sql = `
//                 UPDATE VIN 
//                 SET 
//                     id_vin = ${id_vin},
//                     vin_couleur = ${vin_couleur},
//                     vin_region = ${vin_region},
//                     vin_appellation = ${vin_appellation},
//                     vin_terroir = '${vin_terroir}',
//                     vin_domaine = '${vin_domaine}'
                    
//                 WHERE id_vin = ${req.params.ID}`;
    
//             db.query(sql, (err, result) => {
//                 if (err) {
//                     console.error(err);
//                     res.status(500).send({ message: 'Internal Server Error' });
//                     return;
//                 }
//                 res.send({ status: 1, status_message: 'VIN updated with success.', data: result });
//             });
//         } else {
//             res.status(400).send({ message: 'Invalid id_vin value' });
//         }
// });
    
    
    
   
    


// app.get('/get/bouteilles/:id', (req, res) => {
//     const id_bouteilles = req.params.id;
//     let sql = `
//     SELECT BOUTEILLES.*, EMPLACEMENT.Place, EMPLACEMENT.Presence
//     FROM EMPLACEMENT
//     INNER JOIN BOUTEILLES ON BOUTEILLES.id_bouteilles = EMPLACEMENT.id_bouteilles
//     WHERE BOUTEILLES.id_bouteilles = ?;
//     `;
//     db.query(sql, id_bouteilles, (err, results) => {
//         if(err) throw err;
//         if(results.length === 0) {
//             res.status(404).json({ status: 0, status_message: "Bouteille not found" });
//         } else {
//             res.status(200).json({ status: 1, status_message: "BOUTEILLES data retrieved with success.", bouteilles: results[0] });
//         }
//     });
// });





// app.get('/get/bouteilles', (req, res) => {
//     let sql = `
//     SELECT BOUTEILLES.*, EMPLACEMENT.Place, EMPLACEMENT.Presence
//     FROM EMPLACEMENT
//     INNER JOIN BOUTEILLES ON BOUTEILLES.id_bouteilles = EMPLACEMENT.id_bouteilles;
//     `;
//     db.query(sql, (err, results) => {
//         if(err) throw err;
//         res.send(results);
//     });
// });


// app.get('/get/bouteilles', (req, res) => {
//     let sql = 'SELECT * FROM BOUTEILLES';
//     db.query(sql, (err, results) => {
//         if(err) throw err;
//         res.send(results);
//         // res.sendFile(path.join(__dirname, 'public', 'gestion-cave.html', 'script-gestion.js'));
        
//     });
//     });
// });


// app.get('/get/bouteilles', (req, res) => {
//     let sql = 'SELECT * FROM BOUTEILLES';
//     db.query(sql, (err, results) => {
//         if(err) throw err;
//         res.send(results);
//         // res.sendFile(path.join(__dirname, 'public',  'script-gestion.js'));

//     });
// });

// app.get('/get/bouteilles/:ID', (req, res) => {
//     const sql = 'SELECT * FROM BOUTEILLES WHERE id_bouteilles = ?';
//     db.query(sql, [req.params.ID], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
//             return;
//         }

//         if (result.length > 0) {
//             res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
//         } else {
//             res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
//         }
//     });
// });


// // Configuration du serveur MQTT
// const server = '192.168.5.181'; // Adresse du serveur MQTT

// const topic = 'omar'; // Topic pour écouter les messages

// // Connexion au serveur MQTT
// const client = mqtt.connect(server);

// // Gestion des événements de connexion
// client.on('connect', () => {
//     console.log('Connected to MQTT broker'); // Connexion réussie
//     client.subscribe(topic); // Abonnement au topic pour écouter les messages
// });

// // Gestion des messages reçus
// client.on('message', (receivedTopic, message) => {
//     // Affichage du topic et du message reçus
//     console.log(`Topic: ${receivedTopic}, Message: ${message.toString()}`);
// });


// // Configuration du serveur MQTT
// // const server = 'mqtt://63.34.215.128:1883'; // Adresse du serveur MQTT
// const server = '192.168.5.181'; // Adresse du serveur MQTT

// // const options = {
// //     clientId: 'sofiane', // Identifiant du client MQTT
// //     username: 'imiloratestt', // Nom d'utilisateur pour l'authentification MQTT
// //     password: 'NNSXS.H7B74LGJ5KDODXTN5A52EZQW54NRXZ3S372IMNI.I44IADUFHKQDUQCJWRWU62VYHRET6HDMQ47CS72U4WP4OTIJPWOA' // Mot de passe pour l'authentification MQTT
// // };

// // Connexion au serveur MQTT
// const client = mqtt.connect(server, options);
// client.on('connect', () => {
//     console.log('Connected to MQTT broker'); // Connexion réussie
//     client.subscribe('v3/imiloratestt@ttn/devices/eui-a8610a35301e8909/up', { qos: 0 }); // Abonnement au topic MQTT
// });
// client.on('message', (topic, message) => {
//     // Analyse du message JSON
//     const data = JSON.parse(message.toString());
   
//     // Extraction des valeurs de température et d'humidité
//     const Temperature = data.uplink_message.decoded_payload.temperature;
//     const Humidite = data.uplink_message.decoded_payload.humidity;
   
//     // Affichage des valeurs de température et d'humidité
//     console.log('Température:', Temperature);
//     console.log('Humidité:', Humidite);

//     // Requête SQL pour l'insertion de données dans la table Mesures
//     const query = 'INSERT INTO Mesures (Temperature, Humidite, Time) VALUES (?, ?, ?)';
//     db.query(query, [Temperature, Humidite, new Date()], (err, result) => {
//         if (err) {
//             console.error(err);
//             return;
//         }
//         console.log('Data inserted into database:', result);
//         io.emit('data', { Temperature: Temperature, Humidite: Humidite, Time: new Date() });
//     });
// });


// app.post('/post/mesures', (req, res) => {
//         const {
//             Temperature,
//             Humidite,
//             Time,
//         } = req.body;
    
//         // Requête SQL pour l'insertion de données dans la table VIN
//         const query = 'INSERT IGNORE INTO `Mesures` (`Temperature`, `Humidite`, `Time`) VALUES (?, ?, ?)';
    
//         db.query(query, [Temperature, Humidite, Time], (err, result) => {
//             if (err) {
//                 console.error(err);
//                 res.status(500).send({ message: 'Internal Server Error' });
//                 return;
//             }
    
//             res.send({ message: ' Temperature, Humidite, Time inserted with success.', data: result });
//             console.log(result);
//         });
//     });


// Démarrez le serveur sur le port 3000



// app.get('/get/bouteilles/:ID', (req, res) => {
//     const sql = `
//         SELECT * 
//         FROM BOUTEILLES 
//         INNER JOIN EMPLACEMENT 
//         ON BOUTEILLES.id_bouteilles = EMPLACEMENT.Place 
//         AND EMPLACEMENT.Presence
//         WHERE id_bouteilles = ?`;
        
//     db.query(sql, [req.params.ID], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
//             return;
//         }

//         if (result.length > 0) {
//             res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
//         } else {
//             res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
//         }
//     });
// });





// app.get('/get/bouteilles/vin/:ID', (req, res) => {
//     const sql = 'SELECT * FROM VIN WHERE id_vin = ?';
//     db.query(sql, [req.params.ID], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
//             return;
//         }

//         if (result.length > 0) {
//             res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
//         } else {
//             res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
//         }
//     });
// });


// app.get('/get/bouteilles/:ID', (req, res) => {
//     const sql = `
//     SELECT * FROM BOUTEILLES INNER JOIN EMPLACEMENT ON BOUTEILLES.id_bouteilles = EMPLACEMENT.Place AND EMPLACEMENT.Presence
//     WHERE BOUTEILLES.id_bouteilles = ?
//     `;
//     db.query(sql, [req.params.ID], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
//             return;
//         }

//         if (result.length > 0) {
//             res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
//         } else {
//             res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
//         }
//     });
// });



// app.get('/get/bouteilles/vin/:ID', (req, res) => {
//     const sql = 'SELECT * FROM VIN WHERE id_vin = ?';
//     db.query(sql, [req.params.ID], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.send({ status: 0, status_message: 'Error retrieving BOUTEILLES data.' });
//             return;
//         }

//         if (result.length > 0) {
//             res.send({ status: 1, status_message: 'BOUTEILLES data retrieved with success.', bouteilles: result[0] });
//         } else {
//             res.send({ status: 0, status_message: 'BOUTEILLES not found.' });
//         }
//     });
// });

// Route pour l'insertion de bouteilles

    
    
    
    // db.query(query, [bouteilles_duree, bouteilles_millesime, bouteilles_cote, bouteilles_prix, bouteilles_date_conso, bouteilles_remarques,id_vin], (err, result) => {
    //     if (err) {
    //         console.error(err);
    //         res.status(500).send({ message: 'Internal Server Error' });
    //         return;
    //     }

    //     res.send({ message: 'BOUTEILLES successfully inserted !', data: result });
    //     console.log(result);
    // });






// app.post('/post/bouteillesvin', (req, res) => {
//     const {
//         id_vin,
//         vin_couleur,
//         vin_region,
//         vin_appellation,
//         vin_terroir,
//         vin_domaine,
        
//     } = req.body;

//     // Requête SQL pour l'insertion de données dans la table VIN
//     const query = 'INSERT IGNORE INTO `VIN` (`id_vin`, `vin_couleur`, `vin_region`, `vin_appellation`, `vin_terroir`, `vin_domaine`) VALUES (?, ?, ?, ?, ?, ?)';

//     db.query(query, [id_vin, vin_couleur, vin_region, vin_appellation, vin_terroir, vin_domaine], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send({ message: 'Internal Server Error' });
//             return;
//         }

//         // Après l'insertion, récupérez les détails du vin inséré
//         const insertedVinId = result.insertId;
//         const selectQuery = 'SELECT * FROM VIN WHERE id_vin = ?';
//         db.query(selectQuery, [insertedVinId], (err, vinResult) => {
//             if (err) {
//                 console.error(err);
//                 res.status(500).send({ message: 'Internal Server Error' });
//                 return;
//             }
//             const insertedVin = vinResult[0];

//             // Renvoyez les détails complets du vin inséré avec la réponse
//             res.send({ message: 'VIN inserted with success.', data: insertedVin });
//         });
//     });
// });







